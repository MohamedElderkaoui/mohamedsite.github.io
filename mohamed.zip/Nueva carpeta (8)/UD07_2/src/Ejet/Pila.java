package Ejet;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import Funcion.Leer;
import Funcion.Utilidad;

public class Pila<T> {
	private List<T> t = new ArrayList<>();

	public Pila(List<T> t) {
		super();
		this.t = t;
	}

	/**
	 * @return the t
	 */
	public List<T> getT() {
		return t;
	}

	/**
	 * @param t the t to set
	 */
	public void setT(List<T> t) {
		this.t = t;
	}

	@Override
	public String toString() {
		String n = "";
		Comparator<String> comparator = (a, b) -> a.compareTo(b);
T tt = null;
		n += "\n+";
		n += Utilidad.c(10, "").replace(" ", "-")  + "+\n|";
		String s =("");
		Field[] fields = t.getClass().getFields();
		for (Field field : fields) { s = Leer.leerCadena("");
			n+= Utilidad.c(10, s) + "|";
		}
		n += "\n+";
		n += Utilidad.c(10, "").replace(" ", "-")  + "+\n|";
		for (T i : t) {
			n+= Utilidad.c(10, i.toString()) + "|";
			n += "\n+";
			n += Utilidad.c(10, "").replace(" ", "-")  + "+\n|";
		
		}
		return n;
	}

	public void add(T nT) {
		// TODO Auto-generated method stub
//		this.t.r
		Collections.reverse(t);
this.t.add(0, nT);
Collections.reverse(t);
	}
	public void removelast() {
		// TODO Auto-generated method stub
//		this.t.r
		Collections.reverse(t);
this.t.remove(0);
Collections.reverse(t);

	}
}
