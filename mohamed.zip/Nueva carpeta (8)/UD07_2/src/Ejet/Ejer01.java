package Ejet;

import java.util.ArrayList;
import java.util.List;

import Funcion.Leer;
import Funcion.Utilidad;

public class Ejer01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>list=new ArrayList<>();
		Pila<Integer> pila = new Pila<>(list);
String[] menu = { "salir", "insertar"
		, "quita"
		,"ver"};
	int opcion = -1;
	do {
		if (opcion==1) {
			int objectopcion = Leer.leerEntero("");
			pila.add(objectopcion);
		}else if (opcion==2) {
			pila.removelast();
		}else if (opcion==3) {
			System.out.println(pila.toString());
		}else if (opcion==0) {
			break;
		}
		opcion = Utilidad.leer().leer_opcion_menu("", menu);
	} while (true);
	}

}
