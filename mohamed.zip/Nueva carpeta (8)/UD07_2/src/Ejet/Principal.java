package Hoja2;

import java.util.*;

public class Principal {
	
	public static void main(String[] args) {
		
		ArrayList<Alumno> alum = new ArrayList<>();
		
		String nombre[] = {"Genaro","Claudia","Steven","Sof�a","Javier","Paula","Enrique","Mar�a","Pablo","Teresa"};
		String apellido[] = {"Garc�a", "Sanchez","Lopez","Alonso","Martinez","Fuertes","Gonzalez","P�rez","Val","Ruiz"};

		//crear alumnos aleatorios   +++  50
		for (int i = 0; i < 50; i++) {
			Alumno al1 = new Alumno(nombre[aleatoria(10)],apellido[aleatoria(10)],aleatoria(100),aleatoria(100),aleatoria(100));
			alum.add(al1);
		}

		
		
		//ordenar alumnos
		//----------------------
		ArrayList<Alumno> alumAux = new ArrayList<>(alum);
		
		Comparator<Alumno> c1 = (a1,a2) -> a1.getApellido().compareTo(a2.getApellido());
		Comparator<Alumno> c2 = (a1,a2) -> a1.getNombre().compareTo(a2.getNombre());
		
		Comparator<Alumno> c3 = c1.thenComparing(c2);
		//alumAux.sort(c1.reversed());
		//alumAux.sort(c2);
		alumAux.sort(c3);
		///***********************
		
		
		//for (Alumno a : alumAux) {
		//	System.out.println(a);
		//}
		
		
		//recorrer alumnos y generar los 3 TreeMap<Integer,ArrayList>
		
		TreeMap<Integer,ArrayList<Integer>> tn1 = new TreeMap<>();
		TreeMap<Integer,ArrayList<Integer>> tn2 = new TreeMap<>();
		TreeMap<Integer,ArrayList<Integer>> tn3 = new TreeMap<>();
		
		//for(Alumno a : alumAux) {
		for(int pos=0; pos<alumAux.size();pos++) {
			
			int claveTn1 = alumAux.get(pos).getN1();
			int claveTn2 = alumAux.get(pos).getN2();
			int claveTn3 = alumAux.get(pos).getN3();
			
			ArrayList<Integer> aux1;
			if(tn1.containsKey(claveTn1)) {
				aux1 = tn1.get(claveTn1);
			}else {
				aux1 = new ArrayList<>();
			}
			
			aux1.add(pos);
			tn1.put(claveTn1, aux1);
			
			//-------------------------------------
			ArrayList<Integer> aux2;
			if(tn2.containsKey(claveTn2)) {
				aux2 = tn2.get(claveTn2);
			}else {
				aux2 = new ArrayList<>();
			}
			
			aux2.add(pos);
			tn2.put(claveTn2, aux2);
			
			//-------------------------------------
			ArrayList<Integer> aux3;
			if(tn3.containsKey(claveTn3)) {
				aux3 = tn3.get(claveTn3);
			}else {
				aux3 = new ArrayList<>();
			}
			
			aux3.add(pos);
			tn3.put(claveTn3, aux3);
		}
		
		//mostrar los treeMap
		
		System.out.println("LISTADO NOTA 1:");
		Iterator<Integer> it = tn1.keySet().iterator();
		while(it.hasNext()) {
			int clave = it.next();
			System.out.println("Nota: "+clave);
			ArrayList<Integer> indices = tn1.get(clave);
			for(Integer a: indices)
				System.out.println(alumAux.get(a));
		}
		
		
		System.out.println("LISTADO NOTA 2:");
		for(Integer clave: tn2.keySet()) {
			System.out.println("Nota: "+clave);
			ArrayList<Integer> indices = tn2.get(clave);
			for(Integer a: indices)
				System.out.println(alumAux.get(a));
		}
		
		
		System.out.println("LISTADO NOTA 3:");
		for(Integer clave: tn3.keySet()) {
			System.out.println("Nota: "+clave);
			ArrayList<Integer> indices = tn3.get(clave);
			for(Integer a: indices)
				System.out.println(alumAux.get(a));
		}
		
		
		
	}

	public static int aleatoria(int num) {
		
		int aleat = (int) Math.floor(Math.random()*num);
		
		return aleat;
	}

}
