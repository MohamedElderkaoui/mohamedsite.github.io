package Ejet;

public class Lista {
private Pila<Integer>lISPila=new Pila<Integer>(null);

public Lista() {
	super();
}

/**
 * @return the lISPila
 */
public  Pila<Integer> getlISPila() {
	return lISPila;
}
}
