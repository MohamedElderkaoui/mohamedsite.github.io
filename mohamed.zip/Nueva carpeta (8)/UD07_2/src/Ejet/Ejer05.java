package Hoja2;

import java.util.ArrayList;

public class Ejer05 {
	public static void main(String[] args) {
		
		int ventanillas =2;
		Cola[] oficina = new Cola[ventanillas];
		
		//inicio las ventanillas
		for (int i = 0; i < oficina.length; i++) {
			oficina[i] = new Cola();
		}

		
		
		
		//---------------------------------------------
		
		for(int minuto=1; minuto<=300 ;minuto++) {
			
			
			if(minuto%5==0) {
				//genera tarea
				
				int tarea = aleatoria();
				int pos = minVentanilla(oficina);
				System.out.printf("\t tarea: %d    min:%d  ven: %d \n",tarea,minuto,pos);
				//colocar en la cola cuyo sumatorio de tareas sea m�nimo
				oficina[pos].anadir(tarea);
				//oficina[pos].anadir(tarea);
			}	
			
			if(minuto%15==0) {
				//estadistica
			}
			
			
			
			//actualizar la cola
			for (int i = 0; i < oficina.length; i++) {
				oficina[i].actualizar();
			}
			
			System.out.println(" ");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			pinta(oficina);
		}//final bucle 300
		
		
	}//fin de main
	
	public static int aleatoria() {
		int tarea = 20;
		int aleat = (int) Math.ceil(Math.random()*100);
		
		if(aleat <= 60)
			tarea = 30;
		else if (aleat >= 86)
			tarea = 30;
	
		return tarea;
	}
	
	public static int minVentanilla(Cola[] o) {
		
		int min = 0;
		int pos = 0;
		for (int i = 0; i < o.length; i++) {
			
			if (i == 0 || min > o[i].sumTarea()) {
				min = o[i].sumTarea();
				pos = i;
			}

		}
		
		return pos;
	}
	
	
	public static void pinta(Cola[] o) {
		
		for (int i = 0; i < o.length; i++) {
			
			System.out.printf("| V%d |",i+1);
			
			//System.out.print(o[i].getCola());
			for(int in : o[i].getCola())
				System.out.printf(" %2d |",in);
			
			System.out.printf("\n");
		}
	
	}

}
