import Funcion.Utilidad;

public class EJ26 {
	public static void main(String[] args) {
		String test=Utilidad.leer().leerCadena("intrudoucer"),textf="";
		int j = 80;
		textf=c(j, test);
		System.out.println(textf);
	}

	public static String c(int j, String test) {
		return String.format("%"
				+ (j/2-(test.length()/2))
				+ "s%s%"
				+ (j/2-(test.length()/2))+"s", "", test, "");
	}

	
}
