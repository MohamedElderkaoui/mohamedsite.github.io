import java.util.Arrays;
import java.util.FormatFlagsConversionMismatchException;

import Funcion.*;

public class EJ35 {
	public static void main(String[] args) {
		int []not=new int[10];
		int med=0;
		for (int i = 0; i < not.length; i++) {
			do {
				try {
					int p= Integer.parseInt(Utilidad.leer().leerCadena("nota"+Utilidad.c(10, i)));
					if(p>0) {
						if(p<10) {
							not[i]=p;
							med+=not[i];
							break;
						}
					}
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						
			} while (true);
		}med/=not.length;
		for (int i : not) {
			System.out.printf("%s|", Utilidad.c(4, i));
		}
		System.out.printf("|%s|", Utilidad.c(4, med));
		int p=0;do {
			try {
				p= Integer.parseInt(Utilidad.leer().leerCadena("nota"+Utilidad.c(10, "?")));
				if(p>0) {
					if(p<10) {
						break;
					}
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					
		} while (true);
		Utilidad.leer().miBusca(not, p);
	}

}
