import Funcion.Utilidad;

public class EJ24 {
	public static void main(String[] args) {
		int num = 2;
		boolean esPrimo = Utilidad.leer().esPrimo(num);

		/*
		 * public static boolean esPrimo(int num) { boolean valor = // false true; // //
		 * if ((num%2 !=0 && num%3 !=0 && num%5 != 0) || (num == 2 || num == 3 || num ==
		 * 5) ) // valor = true; int num2 = num; for (int i = 2; i <= num2 / 2; i++) {
		 * if (num % i == 0) { valor = false; break; } } return valor; }
		 */
		if (esPrimo) {
			System.out.println("es    primo");
		} else {
			System.out.println("es no primo");
		}
	}

}
