import Funcion.Utilidad;

public class EJ25 {
	public static void main(String[] args) {
		int num =0;String num_romano = "";
		String[] miles = { "", "M", "MM", "MMM", "MMMM", "MMMMM", "MMMMMM", "MMMMMMM", "MMMMMMMMM", "MMMMMMMMM" };
		String[] cienes = { "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" };
		String[] diezes = { "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" };
		String[] unidades = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" };
		
		do {try {
			num=Integer.parseInt(Utilidad.leer().leerCadena("num"))
				;
			if (num>0) {
				if (num<=4000) {
					break;
				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} while (true);num_romano=
		 miles[num / 1000] + cienes[(num % 1000) / 100] + diezes[(num % 100) / 10] + unidades[num % 10];
	System.out.printf("deci:%d\nromano;%s",num,num_romano);
	}

}
