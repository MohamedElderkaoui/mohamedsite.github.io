

public class EJ03 {
public static void main(String[] args) {
	System.out.print("|");
	for (int i = 1; i < 101; i++) {
		if(i%2==0)
		System.out.print(String.format("%5d|", i));
		else
			System.out.print(String.format("%5s|", ""));	
		if(i%10==0)
			System.out.print(String.format("\n|", i));
	}
}
}
