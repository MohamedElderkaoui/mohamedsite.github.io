import Funcion.Utilidad;

public class EJ28 {
	public static void main(String[] args) {
		int moneda=(int) Math.ceil(Math.random()*2);
		if(moneda==1)
			System.out.println("cara");
		else if(moneda==2)
			System.out.println("cruz");
	}

}
