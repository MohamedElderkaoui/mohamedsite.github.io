
public class EJ21 {
	public static void main(String[] args) {
	int mulplo2=0, mulplo3=0;
	for (int i = 1; i < 1001; i++) {
		if (i%2==0) {
			mulplo2++;
		}
		if (i%3==0) {
			mulplo3++;
		}
	}
	System.out.println(String.format("entre0 y 100 :"
			+ "\n hay m�ltiplos de 2;%d"+ "\n hay m�ltiplos de 3;%d", mulplo2, mulplo3));
}

}
