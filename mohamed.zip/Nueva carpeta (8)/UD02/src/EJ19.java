import Funcion.Utilidad;

public class EJ19 {
	public static void main(String[] args) {
		try {
		
			int hora=0,minuto=0,segundo=0;
			do {
				System.out.printf("\n%02d:%02d:%02d", hora,minuto,segundo);
				
				segundo++;
				if (segundo==60) {
					minuto++;
					segundo=0;
				}
				if (minuto==60) {
					hora++;
				minuto=0;
				}
				if(hora==24)
					hora=0;
				Thread.sleep(2000);
			} while (true);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
