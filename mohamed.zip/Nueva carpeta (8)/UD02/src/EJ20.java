import Funcion.Utilidad;

public class EJ20 {
	public static void main(String[] args) {
		int num = Utilidad.leer().leerEntero("num  ");
		int miFactorial = Utilidad.leer().miFactorial(num);
		System.out.printf("%d!=%d", num,miFactorial);
	}
}
