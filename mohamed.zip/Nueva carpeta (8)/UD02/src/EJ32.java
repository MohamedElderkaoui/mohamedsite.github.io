import java.util.FormatFlagsConversionMismatchException;

import Funcion.*;

public class EJ32 {
	public static void main(String[] args) {int num1 = Leer.leerEntero("Num1: ");
	
	System.out.println("Es primo: "+Leer.esPrimo(num1));
	System.out.println("Factorial: "+Leer.miFactorial(num1));
	Leer.tablaMultiplicar(num1);}

}
