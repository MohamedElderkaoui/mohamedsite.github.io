import Funcion.Utilidad;

public class EJ22 {
	public static void main(String[] args) {
		String text=Utilidad.leer().leerCadena("");
		for (int i = 0; i < 5; i++) {
			System.out.printf("\n%s", text);
			text=String.format("%10s%s", "",text);
		}
	}

}
