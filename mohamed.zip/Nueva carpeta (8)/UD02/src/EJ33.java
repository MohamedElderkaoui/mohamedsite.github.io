import java.util.Arrays;
import java.util.FormatFlagsConversionMismatchException;

import Funcion.*;

public class EJ33 {
	public static void main(String[] args) {
		String[] nombrStrings = { "mohamed", "el derkaoui", "juan", "marco", "jarvier", "ivan", "ismail", "isma3l",
				"ilies", "carlos", "inazio" };
		for (String i : nombrStrings) {

			System.out.printf("%10s", i);
		}
		for (int i = 0; i < nombrStrings.length; i++) {
			for (int j = 0; j < nombrStrings.length - 1; j++) {
				if (nombrStrings[j].compareToIgnoreCase(nombrStrings[j + 1]) > 0) {
					String _n = "\n";
					_n = nombrStrings[j + 1];
					nombrStrings[j + 1] = nombrStrings[j];
					nombrStrings[j] = _n;
				}
			}
		}
		System.out.println();
		System.out.println("ordenar");
		for (String i : nombrStrings) {

			System.out.printf("%10s", i);
		}
	}

}
