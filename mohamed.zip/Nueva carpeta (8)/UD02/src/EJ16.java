import Funcion.Utilidad;

public class EJ16 {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.printf("%6d.", j);
			}
			System.out.println();
		}
	}
}
