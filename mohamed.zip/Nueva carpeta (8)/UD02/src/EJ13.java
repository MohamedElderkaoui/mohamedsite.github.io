import Funcion.Utilidad;

public class EJ13 {
	public static void main(String[] args) {
		int mulplo2=0, mulplo3=0;
		int num = Utilidad.leer().leerEntero("num");

		for (int i = 1; i < num+1; i++) {
			if (i%2==0) {
				mulplo2++;
			}
			if (i%3==0) {
				mulplo3++;
			}
		}
		System.out.println(String.format("entre0 y %d :"
				+ "\n hay m�ltiplos de 2;%d"+ "\n hay m�ltiplos de 3;%d",num, mulplo2, mulplo3));
	}
}
