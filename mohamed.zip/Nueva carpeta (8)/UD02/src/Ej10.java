import Funcion.Utilidad;

public class Ej10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Utilidad.leer().leerEntero("num");
	if (num%2==0) {
		System.out.printf("%d es PAR", num);
	}else {
		System.out.printf("%d es IMPAR", num);
		
	}
	}

}
