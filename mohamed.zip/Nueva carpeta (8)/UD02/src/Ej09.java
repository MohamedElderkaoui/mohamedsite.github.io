import Funcion.Utilidad;

public class Ej09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Utilidad.leer().leerEntero("num");
	if (num<0) {
		System.out.printf("%d es nnegativo", num);
	}else {
		System.out.printf("%d es positivo", num);
		
	}
	}

}
