
public class EJ04 {
public static void main(String[] args) {
	int suma =0;
	for (int i = 0; i < 102; i++) {
		suma+=i;
	}
	System.out.println(String.format(" la suma de los 100 primeros n�meros es %d", suma));
}
}
