import Funcion.Utilidad;

public class EJ18 {
	public static void main(String[] args) {
		String textString="",letra="";
		int cont=0;
		do {cont=0;
			textString=Utilidad.leer().leerCadena("frase que introduciremos aque");
			if (textString.length()==0) {
				break;
			} else {
				do {

					letra=Utilidad.leer().leerCadena("frase que introduciremos aque");
			 if (letra.length()==1) {
				break;
			}
				} while (true);
				for (int i = 0; i < textString.length(); i++) {
					if (textString.substring(i, i+1).compareToIgnoreCase(letra.substring(0, 1))==0) {
						cont++;
					}
				}
				System.out.printf("en la frase %80s hay %d veces la letra %s", textString,cont,letra);
			}
		} while (true);
	}
}
