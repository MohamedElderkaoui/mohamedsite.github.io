import Funcion.Utilidad;

public class Ej08 {
	public static void main(String[] args) {
		String texto = "";
		do {
			texto = Utilidad.leer().leerCadena("introducer s/n");
			if (texto.compareToIgnoreCase("s")==0) {
				break;
			}else if (texto.compareToIgnoreCase("n")==0) {
				break;
			}
		} while (true);
	}
}
