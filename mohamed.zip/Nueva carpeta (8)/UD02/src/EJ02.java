

public class EJ02 {
public static void main(String[] args) {
	for (int i = 0; i < 100; i++) {
		System.out.print(String.format("%5d|", 100-i));
	}
}
}
