import Funcion.Utilidad;

public class EJ06 {
public static void main(String[] args) {
	int num = Utilidad.leer().leerEntero("num");
	for (int i = 0; i < num; i++) {
		System.out.print(String.format("%5d|", i));
	}
	
}
}
