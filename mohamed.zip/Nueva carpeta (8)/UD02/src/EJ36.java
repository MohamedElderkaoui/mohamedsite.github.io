import java.util.Arrays;
import java.util.FormatFlagsConversionMismatchException;

import Funcion.*;

public class EJ36 {
	public static void main(String[] args) {
		int not[][]=new int[4][5];
		for (int i = 0; i < not.length; i++) {
			for (int j = 0; j < not[i].length; j++) {
				not[][]
			}
		}
	}

}
