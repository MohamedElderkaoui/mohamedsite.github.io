import java.util.FormatFlagsConversionMismatchException;
import java.util.Scanner;

import Funcion.Utilidad;

public class EJ30 {
	public static void main(String[] args) {

		String[] menu = { "salir", "suma" , "resrta" , "multiplcar" , "dividir" };
		int opcion = -1;
		do {
			if (opcion == 1) {
				int a, b, c = 0;
				Scanner teclado = new Scanner(System.in);
				do {
					try {
						System.out.printf("introducer numero a", " ");
						a = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				do {
					try {
						System.out.printf("introducer numero b", " ");
						b = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				int i = a-b;
				System.out.printf("%d-%d=%f", a,b,i);
			} else if (opcion == 2) {
				int a, b, c = 0;
				Scanner teclado = new Scanner(System.in);
				do {
					try {
						System.out.printf("introducer numero a", " ");
						a = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				do {
					try {
						System.out.printf("introducer numero b", " ");
						b = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				int i = a-b;
				System.out.printf("%d-%d=%f", a,b,i);
			} else if (opcion == 3) {
				int a, b, c = 0;
				Scanner teclado = new Scanner(System.in);
				do {
					try {
						System.out.printf("introducer numero a", " ");
						a = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				do {
					try {
						System.out.printf("introducer numero b", " ");
						b = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				int i = a*b;
				System.out.printf("%d*%d=%f", a,b,i);
			} else if (opcion == 4) {
				int a, b, c = 0;
				Scanner teclado = new Scanner(System.in);
				do {
					try {
						System.out.printf("introducer numero a", " ");
						a = Integer.parseInt(teclado.nextLine());
						break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				do {
					try {
						System.out.printf("introducer numero b", " ");
						b = Integer.parseInt(teclado.nextLine());
						if (b != 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				float i = a/b;
				System.out.printf("%d/%d=%f", a,b,i);
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
	}

}
