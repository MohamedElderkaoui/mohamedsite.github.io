import Funcion.Utilidad;

public class EJ29 {
	public static void main(String[] args) {
		
		//tirada de dos dados
		
		int cont = 0;
		
		for(int i=0;i<100;i++) {
			int dado1 = (int) Math.ceil(Math.random()*6);
			int dado2 = (int) Math.ceil(Math.random()*6);
			
			if(dado1+dado2==10) {
				cont++;
			}
		}
		
		System.out.println("los dados han sumado 10: "+cont+" veces.");
		
		
	}

}
