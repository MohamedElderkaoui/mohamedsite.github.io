import Funcion.Utilidad;

public class EJ27 {
	public static void main(String[] args) {
		int num = 0;
		do {
			try {
				num = Integer.parseInt(Utilidad.leer().leerCadena(" intrudoucerdd"));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				System.err.println("error");
			}
			if (num > 0)
				if (num < 10)
					break;

		} while (true);
		
		for (int i = 0; i < 11; i++) {
			System.out.println(String.format("%6dx%6d=%6d", num,i,(num*i)));
		}
	}

}
