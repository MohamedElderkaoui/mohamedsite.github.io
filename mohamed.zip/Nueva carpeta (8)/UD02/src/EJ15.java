import Funcion.Utilidad;

public class EJ15 {
	public static void main(String[] args) {
		int max=0,min=0,conimp=0,sumapar=0,cont=0;
		for (int i = 0; i <2; i++) {
			int num=Utilidad.leer().leerEntero("");
			if (i==0) {
				max=num;
				min=num;
			} else {
				if (num>max) {
					max=num;
				}
				if (num<min) {
					min=num;
				}
				
			}
		}
		for (int i = min; i < max+1; i++) {
			cont++;
			if (i%2==0) {
				sumapar+=i;
			}else {
				conimp++;
			}
		}
		System.out.printf("  cuantos hay %dy cu�ntos de ellos son pares.%d Calcular la suma de los impares.%d", cont,conimp,sumapar);
		}
}
