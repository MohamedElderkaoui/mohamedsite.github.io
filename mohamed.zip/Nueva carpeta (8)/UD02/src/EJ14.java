import Funcion.Utilidad;

public class EJ14 {
	public static void main(String[] args) {
		int max=0,min=0;
		for (int i = 0; i <5; i++) {
			int num=Utilidad.leer().leerEntero("");
			if (i==0) {
				max=num;
				min=num;
			} else {
				if (num>max) {
					max=num;
				}
				if (num<min) {
					min=num;
				}
				
			}
		}
		
		System.out.printf("maximo:%d\nminimo=%d", max,min);
}
}
