import Funcion.Utilidad;

public class EJ07 {
public static void main(String[] args) {
	String textoString="";
	int cont=0;
	do {
		textoString=Utilidad.leer().leerCadena("nuevo texto");
		if (textoString.isEmpty()==true) {
			System.out.println(String.format("hay %10d frases", cont));
			break;
		}cont++;
	} while (true);
}
}
