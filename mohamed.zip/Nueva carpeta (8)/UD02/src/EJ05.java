
public class EJ05 {
public static void main(String[] args) {
	System.out.print("|");int par=0;
	for (int i = 1; i < 101; i++) {
		if(i%2==0) {
			par++;
		} else
		 {
			String num_impar = String.format("%5d|", i);
			System.out.print(num_impar);
		} 	
		if(i%10==0)
			System.out.print(String.format("\n|", i));
	}
	System.out.println();
	String num_par = String.format("%5d|", par);
	System.out.print(num_par);
}

}
