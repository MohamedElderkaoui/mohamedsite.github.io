import java.util.FormatFlagsConversionMismatchException;

import Funcion.Utilidad;

public class EJ31 {
	public static void main(String[] args) {
		int[] caballos = new int[5];
		boolean f = false;
		do {
			try {
				for (int i = 0; i < caballos.length; i++) {
					int dado1 = (int) Math.ceil(Math.random() * 5);
					caballos[i] += dado1;
					
				}
				for (int i = 0; i < caballos.length; i++) {
					System.out.printf("%"
							+ caballos[i] 
							+ "s", (""+i));
					System.out.printf("%"
									+ (40-caballos[i] )
											+ "s", ("|\n"));
					
				}
				Thread.sleep(3000);
				for (int i = 0; i <100; i++) {
					System.out.println();
				}
				for (int i = 0; i < caballos.length; i++)
					if (caballos[i] >= 40) {
						f = !f;
						System.out.printf("ha ganado caballosn�%d", i);
					}
				if (f)
					break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	} catch (FormatFlagsConversionMismatchException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} while (true);
	}

}
