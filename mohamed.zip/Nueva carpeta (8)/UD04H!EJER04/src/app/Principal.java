package app;

import java.util.Arrays;

import Funcion.Leer;
import Funcion.Utilidad;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CuentaCorriente cuentaCorrientes[] = new CuentaCorriente[1];
		String[] menu = { "salir", "Crear nueva cuenta ", "Ingresar en cuenta ", "Retirar de cuenta ",
				"Visualizar cuenta ", "Visualiza todas las cuentas " };
		int opcion = -1;
		do {
			if (opcion == 1) {
				vir(cuentaCorrientes);

				Double ler = 0.0;
				do {
					try {
						ler = Double.parseDouble(Leer.leerCadena("sado").replace(",", "."));
						if (ler > 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				String cliente = Leer.leerCadena("cliente");
				CuentaCorriente cuentaCorriente = new CuentaCorriente(ler, cliente);
				cuentaCorrientes = Arrays.copyOf(cuentaCorrientes, cuentaCorrientes.length + 1);
				for (int i = 0; i < cuentaCorrientes.length; i++) {
					if (cuentaCorrientes[i] == null) {
						cuentaCorrientes[i] = cuentaCorriente;
						break;
					}
				}
				vir(cuentaCorrientes);

			} else if (opcion == 2) {
				vir(cuentaCorrientes);
				int objectopcion = -1;
				objectopcion = extracted(cuentaCorrientes);

				Double ler = 0.0;
				do {
					try {
						ler = Double.parseDouble(Leer.leerCadena("sado").replace(",", "."));
						if (ler > 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				vir(cuentaCorrientes);
			} else if (opcion == 3) {
				vir(cuentaCorrientes);
				int objectopcion = -1;
				Double ler = 0.0;
				do {
					try {
						ler = Double.parseDouble(Leer.leerCadena("sado").replace(",", "."));
						if (ler > 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				objectopcion = extracted(cuentaCorrientes);
				cuentaCorrientes[objectopcion].INGRESA(ler);
				vir(cuentaCorrientes);
			} else if (opcion == 4) {
				vir(cuentaCorrientes);
				int objectopcion = -1;
				objectopcion = extracted(cuentaCorrientes);
				Double ler = 0.0;
				do {
					try {
						ler = Double.parseDouble(Leer.leerCadena("sado").replace(",", "."));
						if (ler > 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				cuentaCorrientes[objectopcion].Retirar(ler);
				vir(cuentaCorrientes);
			} else if (opcion == 5) {
				vir(cuentaCorrientes);
				int objectopcion = -1;
				objectopcion = extracted(cuentaCorrientes);
				System.out.println(cuentaCorrientes[objectopcion].ver());
			} else if (opcion == 6) {
				vir(cuentaCorrientes);
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
	}

	public static void vir(CuentaCorriente[] cuentaCorrientes) {
		String t = "\n";
		t += String.format("%s+%s+\n", Utilidad.c(10, ""), Utilidad.c(10, "")).replace(" ", "-");
		t += String.format("%s|%s|%s|\n", Utilidad.c(10, "color"), Utilidad.c(10, "comido"), Utilidad.c(10, "maximo"));
		t += String.format("%s+%s+%s+\n", Utilidad.c(10, ""), Utilidad.c(10, "")).replace(" ", "-");
		for (CuentaCorriente i : cuentaCorrientes) {
			if (i != null) {
				t += i.toString();
			}
		}
		System.out.println(t);
	}

	public static int extracted(CuentaCorriente[] cuentaCorrientes) {
		int objectopcion = -1;
		do {
			try {
				objectopcion = Integer.parseInt(Leer.leerCadena(""));
				if (objectopcion > -1)
					if (objectopcion < cuentaCorrientes.length)
						return objectopcion;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} while (true);
	}

}
