package app;

import Funcion.Utilidad;

public class CuentaCorriente {

	private String numCuenta;
	private double saldo;
	private  String cliente;
	private static int numSig = 1;

	public CuentaCorriente(double saldo, String cliente) {
		this.numCuenta = String.format("cc%04d", numSig);
		numSig++;
		this.saldo = saldo;
		this.cliente = cliente;
	}

	/**
	 * @return the numCuenta
	 */
	public String getNumCuenta() {
		return numCuenta;
	}

	/**
	 * @param numCuenta the numCuenta to set
	 */
	public void setNumCuenta(String numCuenta) {
		this.numCuenta = numCuenta;
	}

	/**
	 * @return the saldo
	 */
	public double getSaldo() {
		return saldo;
	}

	/**
	 * @param saldo the saldo to set
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * @return the cliente
	 */
	public  String getCliente() {
		return cliente;
	}

	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	/**
	 * @return the numSig
	 */
	public static int getNumSig() {
		return numSig;
	}

	/**
	 * @param numSig the numSig to set
	 * 
	 *               public static void setNumSig(int numSig) {
	 *               CuentaCorriente.numSig = numSig; }
	 */
	@Override
	public String toString() {
		return String.format("%s| %s|\n", Utilidad.c(10, numCuenta), Utilidad.c(10, String.format("%F", saldo)),
				cliente.toString())+String.format("%s+%s+%s+\n",  Utilidad.c(10, ""), Utilidad.c(10, "")).replace(" ",
						"-");
	}

	public String ver() {
		return String.format("%s| %s| %s|", Utilidad.c(10, numCuenta), Utilidad.c(10, String.format("%F", saldo)),
				cliente.toString());
	}

	public void INGRESA(double saldo) {
		this.saldo += saldo;
	}

	public boolean Retirar(double saldo) {
		boolean b = false;
		if (this.saldo - saldo >= 0.0) {
			this.saldo -= saldo;
			b = !b;
		}
		return b;
	}
public  CuentaCorriente name(CuentaCorriente o) {
	CuentaCorriente nCorriente=null;
	
		String cliente = getCliente();
		if ((o.getCliente().compareTo(cliente))==0) {nCorriente = new CuentaCorriente(o.getSaldo()+getSaldo(), cliente);
		nCorriente.setNumCuenta(this.numCuenta);
		} 
	return nCorriente;
	
}
}
