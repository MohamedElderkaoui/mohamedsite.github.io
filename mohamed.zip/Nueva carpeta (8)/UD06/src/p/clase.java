package p;

import java.util.List;

public class Clase {

  private List<Estudiante> estudiantes;

  private Profesor pa;
}