package p;

public class Servico extends Empleado {

  private String departamento;

public Servico(String departamento) {
	super();
	this.departamento = departamento;
}

public Servico() {
	// TODO Auto-generated constructor stub
}

/**
 * @return the departamento
 */
public synchronized String getDepartamento() {
	return departamento;
}

/**
 * @param departamento the departamento to set
 */
public synchronized void setDepartamento(String departamento) {
	this.departamento = departamento;
}

@Override
public String toString() {
	return String.format("%s|", departamento);
}
}