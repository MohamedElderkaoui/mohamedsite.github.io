package p;

import java.util.ArrayList;
import java.util.List;

import Funcion.Leer;
import Funcion.Utilidad;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Persona> list = new ArrayList<>();
		String[] menu = { "salir", "insertar", "Cambio del estado civil de una persona. ",
				"Reasignaci�n de despacho a un empleado. ", "Matriculaci�n de un estudiante en un nuevo curso. ",
				"Cambio de departamento de un profesor.",
				"Traslado de secci�n de un empleado del personal de servicio. ",
				"Imprimir toda la informaci�n de cada tipo de individuo. " };
		int opcion = -1;
		do {
			if (opcion == 1) {
				list = insertar(list);
			} else if (opcion == 2) {
				ver_estado(list);
				int objectopcion = -1;
				do {
					ver_estado(list);
					objectopcion = Integer.parseInt(Leer.leerCadena(""));
					if (objectopcion > -1) {
						if (objectopcion < list.size()) {
							list.get(objectopcion).setEstado(Leer.leerCadena(""));
							break;
						}
					}

				} while (true);
				ver_estado(list);
			} else if (opcion == 3) {
				ver_depach(list);
				int objectopcion = -1;
				do {
					if (objectopcion > -1) {
						if (objectopcion < list.size()) {
							if (list.get(objectopcion) instanceof Profesor) {
								((Profesor) list.get(objectopcion)).setDepartamento();
								break;
							}
						}
					}
					ver_estado(list);
					objectopcion = Integer.parseInt(Leer.leerCadena(""));
				} while (true);
				ver_depach(list);
			} else if (opcion == 4) {
				ver_curs(list);
				int objectopcion = -1;
				do {
					objectopcion = Integer.parseInt(Leer.leerCadena(""));
					if (objectopcion > -1) {
						if (objectopcion < list.size()) {
							if (list.get(objectopcion) instanceof Estudiante) {
								((Estudiante) list.get(objectopcion)).setCurso();
								break;
							}
						}
					}
					ver_estado(list);
				} while (true);
				ver_curs(list);
			} else if (opcion == 5) {
				ver(list);
				int objectopcion = -1;
				do {
					ver_estado(list);
					objectopcion = Integer.parseInt(Leer.leerCadena(""));
					if (objectopcion > -1) {
						if (objectopcion < list.size()) {
							if (list.get(objectopcion) instanceof Servico) {
								((Servico) list.get(objectopcion)).setDepartamento(Leer.leerCadena(""));
								break;
							}
						}
					}

				} while (true);
				ver(list);
			} else if (opcion == 6) {
				for (Persona i : list) {

				}

			} else if (opcion == 0) {
				break;

			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);

	}

	public static void ver(List<Persona> list) {
		if (true) {
			String t = "";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+\n|";
			t += Utilidad.c(15, "n") + "|";//
			t += Utilidad.c(15, "NOM APREIDO") + "|";//
			t += Utilidad.c(15, "depach".toUpperCase()) + "|";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			for (Persona i : list) {
				if (i instanceof Servico) {
					t += "+\n|";
					t += Utilidad.c(15, list.indexOf(i)) + "|";//
					t += Utilidad.c(15, i.getNombre() + " " + i.getApellidos()) + "|";//
					t += Utilidad.c(15, ((Servico) i).getDepartamento()) + "|\n";
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
				}
			}
			System.out.println(t);
		}
	}

	public static void ver_curs(List<Persona> list) {
		if (true) {
			String t = "";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+\n|";
			t += Utilidad.c(15, "n") + "|";//
			t += Utilidad.c(15, "NOM APREIDO") + "|";//
			t += Utilidad.c(15, "curso".toUpperCase()) + "|";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			for (Persona i : list) {
				if (i instanceof Estudiante) {
					t += "+\n|";
					t += Utilidad.c(15, list.indexOf(i)) + "|";//
					t += Utilidad.c(15, i.getNombre() + " " + i.getApellidos()) + "|";//
					t += Utilidad.c(15, ((Estudiante) i).getCurso()) + "|\n";
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
				}
			}
			System.out.println(t);
		}
	}

	public static void ver_depach(List<Persona> list) {
		if (true) {
			String t = "";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+\n|";
			t += Utilidad.c(15, "n") + "|";//
			t += Utilidad.c(15, "NOM APREIDO") + "|";//
			t += Utilidad.c(15, "depach".toUpperCase()) + "|";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			for (Persona i : list) {
				if (i instanceof Profesor) {
					t += "+\n|";
					t += Utilidad.c(15, list.indexOf(i)) + "|";//
					t += Utilidad.c(15, i.getNombre() + " " + i.getApellidos()) + "|";//
					t += Utilidad.c(15, ((Profesor) i).getDepartamento()) + "|\n";
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
					t += Utilidad.c(15, "").replace(" ", "-");
					t += "+";
				}
			}
			System.out.println(t);
		}
	}

	public static void ver_estado(List<Persona> list) {
		if (true) {
			String t = "";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+\n|";
			t += Utilidad.c(15, "NOM APREIDO") + "|";//
			t += Utilidad.c(15, " estado civil".toUpperCase()) + "|";
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			t += "+";
			t += Utilidad.c(15, "").replace(" ", "-");
			for (Persona i : list) {
				t += "+\n|";
				t += Utilidad.c(15, i.getNombre() + " " + i.getApellidos()) + "|";//
				t += Utilidad.c(15, i.getEstado()) + "|";
				t += "+";
				t += Utilidad.c(15, "").replace(" ", "-");
				t += "+";
				t += Utilidad.c(15, "").replace(" ", "-");
			}
			System.out.println(t);
		}
	}

	private static List<Persona> insertar(List<Persona> list) {
		// TODO Auto-generated method stub
		String[] menu = { "salir", "estudiante", "profesor", "t servision" };
		int opcion = -1;
		do {
			if (opcion == 1) {
				Estudiante nu = new Estudiante();
				if (!list.contains(nu))
					list.add(nu);
				break;

			} else if (opcion == 2) {
				Profesor profesor = new Profesor();
				if (!list.contains(profesor))
					list.add(profesor);
				break;

			} else if (opcion == 3) {
				Servico servico = new Servico("");
				break;
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
		return list;
	}

}
