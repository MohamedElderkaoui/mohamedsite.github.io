package p;

import Funcion.*;

public class Estudiante extends Persona {

	private String curso;

	public Estudiante() {
		super();
		if (true) {
			String[] menu = { "salir", "0 a�o ", "1 a�o " //
					, "2 anos" //
					, "3 a�osa" //
					, "3 anosb" //
					, "4 a�osa" //
					, "4 anosb" //
					, "6 a�osa" //
					, "6 anosb" //
					, "1 primariasa " //
					, "1 primariasb " //
					, "2 primariasa" //
					, "2 primariasb" //
					, "3 primariasa" //
					, "3 primariasb" //
					, "4 primariasa" //
					, "4 primariasb" //
					, "6 primariasa" //
					, "6 primariasb" //
					, "1 esoa " //
					, "1 esob " //
					, "1 esoc " //
					, "1 esod " //
					, "2 esoa " //
					, "2 esob " //
					, "2 esoc " //
					, "2 esod " //
					, "3 esoa " //
					, "3 esob " //
					, "3 esoc " //
					, "3 esod " //
					, "4 esoa " //
					, "4 esob " //
					, "4 esoc " //
					, "4 esod " //
					, "1 bachilerato tecnogico" //
					, "1 bachileratobiolog�a " //
					, "1 bachileratoArtes " //
					, "1 bachileratoHumanidades y Ciencias sociales " //
					, "2 bachilerato tecnogico" //
					, "2 bachileratobiolog�a " //
					, "2 bachileratoArtes " //
					, "2 bachileratoHumanidades y Ciencias sociales " //
					, "1 gm Actividades F�sicas y Deportivas" //
					, "1 gm Administraci�n y Gesti�n" //
					, "1 gm Agraria" //
					, "1 gm Artes Gr�ficas" //
					, "1 gm Artes y Artesan�as" //
					, "1 gm Comercio y Marketing" //
					, "1 gm Edificaci�n y Obra Civil" //
					, "1 gm Electricidad y Electr�nica" //
					, "1 gm Energ�a y Agua" //
					, "1 gm Fabricaci�n Mec�nica" //
					, "1 gm Hosteler�a y Turismo" //
					, "1 gm Imagen Personal" //
					, "1 gm Imagen y Sonido" //
					, "1 gm Industrias Alimentarias" //
					, "1 gm Industrias Extractivas" //
					, "1 gm Inform�tica y Comunicaciones" //
					, "1 gm Instalaci�n y Mantenimiento" //
					, "1 gm Madera, Mueble y Corcho" //
					, "1 gm Mar�timo-Pesquera" //
					, "1 gm Qu�mica" //
					, "1 gm Sanidad" //
					, "1 gm Seguridad y Medio Ambiente" //
					, "1 gm Servicios Socioculturales y a la Comunidad" //
					, "1 gm Textil, Confecci�n y Piel" //
					, "1 gm Transporte y Mantenimiento de Veh�culos" //
					, "1 gm Vidrio y Cer�mica" //
												//
					, "2 gm gm Actividades F�sicas y Deportivas" //
					, "2 gm gm Administraci�n y Gesti�n" //
					, "2 gm gm Agraria" //
					, "2 gm gm Artes Gr�ficas" //
					, "2 gm gm Artes y Artesan�as" //
					, "2 gm gm Comercio y Marketing" //
					, "2 gm gm Edificaci�n y Obra Civil" //
					, "2 gm gm Electricidad y Electr�nica" //
					, "2 gm gm Energ�a y Agua" //
					, "2 gm gm Fabricaci�n Mec�nica" //
					, "2 gm gm Hosteler�a y Turismo" //
					, "2 gm gm Imagen Personal" //
					, "2 gm gm Imagen y Sonido" //
					, "2 gm gm Industrias Alimentarias" //
					, "2 gm gm Industrias Extractivas" //
					, "2 gm gm Inform�tica y Comunicaciones" //
					, "2 gm gm Instalaci�n y Mantenimiento" //
					, "2 gm gm Madera, Mueble y Corcho" //
					, "2 gm gm Mar�timo-Pesquera" //
					, "2 gm gm Qu�mica" //
					, "2 gm gm Sanidad" //
					, "2 gm gm Seguridad y Medio Ambiente" //
					, "2 gm gm Servicios Socioculturales y a la Comunidad" //
					, "2 gm gm Textil, Confecci�n y Piel" //
					, "2 gm gm Transporte y Mantenimiento de Veh�culos" //
					, "2 gm gm Vidrio y Cer�mica" //

					, "1 gspf Actividades F�sicas y Deportivas" //
					, "1 gspf Administraci�n y Gesti�n" //
					, "1 gspf Agraria" //
					, "1 gspf Artes Gr�ficas" //
					, "1 gspf Artes y Artesan�as" //
					, "1 gspf Comercio y Marketing" //
					, "1 gspf Edificaci�n y Obra Civil" //
					, "1 gspf Electricidad y Electr�nica" //
					, "1 gspf Energ�a y Agua" //
					, "1 gspf Fabricaci�n Mec�nica" //
					, "1 gspf Hosteler�a y Turismo" //
					, "1 gspf Imagen Personal" //
					, "1 gspf Imagen y Sonido" //
					, "1 gspf Industrias Alimentarias" //
					, "1 gspf Industrias Extractivas" //
					, "1 gspf Inform�tica y Comunicaciones" //
					, "1 gspf Instalaci�n y Mantenimiento" //
					, "1 gspf Madera, Mueble y Corcho" //
					, "1 gspf Mar�timo-Pesquera" //
					, "1 gspf Qu�mica" //
					, "1 gspf Sanidad" //
					, "1 gspf Seguridad y Medio Ambiente" //
					, "1 gspf Servicios Socioculturales y a la Comunidad" //
					, "1 gspf Textil, Confecci�n y Piel" //
					, "1 gspf Transporte y Mantenimiento de Veh�culos" //
					, "1 gspf Vidrio y Cer�mica" //
					//
					, "2 gspf Actividades F�sicas y Deportivas" //
					, "2 gspf Administraci�n y Gesti�n" //
					, "2 gspf Agraria" //
					, "2 gspf Artes Gr�ficas" //
					, "2 gspf Artes y Artesan�as" //
					, "2 gspf Comercio y Marketing" //
					, "2 gspf Edificaci�n y Obra Civil" //
					, "2 gspf Electricidad y Electr�nica" //
					, "2 gspf Energ�a y Agua" //
					, "2 gspf Fabricaci�n Mec�nica" //
					, "2 gspf Hosteler�a y Turismo" //
					, "2 gspf Imagen Personal" //
					, "2 gspf Imagen y Sonido" //
					, "2 gspf Industrias Alimentarias" //
					, "2 gspf Industrias Extractivas" //
					, "2 gspf Inform�tica y Comunicaciones" //
					, "2 gspf Instalaci�n y Mantenimiento" //
					, "2 gspf Madera, Mueble y Corcho" //
					, "2 gspf Mar�timo-Pesquera" //
					, "2 gspf Qu�mica" //
					, "2 gspf Sanidad" //
					, "2 gspf Seguridad y Medio Ambiente" //
					, "2 gspf Servicios Socioculturales y a la Comunidad" //
					, "2 gspf Textil, Confecci�n y Piel" //
					, "2 gspf Transporte y Mantenimiento de Veh�culos" //
					, "2 gspf Vidrio y Cer�mica" //

					//
					//
			};
			int opcion = -1;
			do {
				if (opcion == 0) {
					System.err.println("no se puede");

				} else if (opcion > 0) {
					this.curso = menu[opcion];
				}
				opcion = Utilidad.leer().leer_opcion_menu("", menu);
			} while (true);
		}
	}

	/**
	 * @return the curso
	 */
	public synchronized String getCurso() {
		return curso;
	}

	/**
	 * @param curso the curso to set
	 */
	public synchronized void setCurso(/*String curso*/) {
		if (true) {
			String[] menu = { "salir", "0 a�o ", "1 a�o " //
					, "2 anos" //
					, "3 a�osa" //
					, "3 anosb" //
					, "4 a�osa" //
					, "4 anosb" //
					, "6 a�osa" //
					, "6 anosb" //
					, "1 primariasa " //
					, "1 primariasb " //
					, "2 primariasa" //
					, "2 primariasb" //
					, "3 primariasa" //
					, "3 primariasb" //
					, "4 primariasa" //
					, "4 primariasb" //
					, "6 primariasa" //
					, "6 primariasb" //
					, "1 esoa " //
					, "1 esob " //
					, "1 esoc " //
					, "1 esod " //
					, "2 esoa " //
					, "2 esob " //
					, "2 esoc " //
					, "2 esod " //
					, "3 esoa " //
					, "3 esob " //
					, "3 esoc " //
					, "3 esod " //
					, "4 esoa " //
					, "4 esob " //
					, "4 esoc " //
					, "4 esod " //
					, "1 bachilerato tecnogico" //
					, "1 bachileratobiolog�a " //
					, "1 bachileratoArtes " //
					, "1 bachileratoHumanidades y Ciencias sociales " //
					, "2 bachilerato tecnogico" //
					, "2 bachileratobiolog�a " //
					, "2 bachileratoArtes " //
					, "2 bachileratoHumanidades y Ciencias sociales " //
					, "1 gm Actividades F�sicas y Deportivas" //
					, "1 gm Administraci�n y Gesti�n" //
					, "1 gm Agraria" //
					, "1 gm Artes Gr�ficas" //
					, "1 gm Artes y Artesan�as" //
					, "1 gm Comercio y Marketing" //
					, "1 gm Edificaci�n y Obra Civil" //
					, "1 gm Electricidad y Electr�nica" //
					, "1 gm Energ�a y Agua" //
					, "1 gm Fabricaci�n Mec�nica" //
					, "1 gm Hosteler�a y Turismo" //
					, "1 gm Imagen Personal" //
					, "1 gm Imagen y Sonido" //
					, "1 gm Industrias Alimentarias" //
					, "1 gm Industrias Extractivas" //
					, "1 gm Inform�tica y Comunicaciones" //
					, "1 gm Instalaci�n y Mantenimiento" //
					, "1 gm Madera, Mueble y Corcho" //
					, "1 gm Mar�timo-Pesquera" //
					, "1 gm Qu�mica" //
					, "1 gm Sanidad" //
					, "1 gm Seguridad y Medio Ambiente" //
					, "1 gm Servicios Socioculturales y a la Comunidad" //
					, "1 gm Textil, Confecci�n y Piel" //
					, "1 gm Transporte y Mantenimiento de Veh�culos" //
					, "1 gm Vidrio y Cer�mica" //
												//
					, "2 gm gm Actividades F�sicas y Deportivas" //
					, "2 gm gm Administraci�n y Gesti�n" //
					, "2 gm gm Agraria" //
					, "2 gm gm Artes Gr�ficas" //
					, "2 gm gm Artes y Artesan�as" //
					, "2 gm gm Comercio y Marketing" //
					, "2 gm gm Edificaci�n y Obra Civil" //
					, "2 gm gm Electricidad y Electr�nica" //
					, "2 gm gm Energ�a y Agua" //
					, "2 gm gm Fabricaci�n Mec�nica" //
					, "2 gm gm Hosteler�a y Turismo" //
					, "2 gm gm Imagen Personal" //
					, "2 gm gm Imagen y Sonido" //
					, "2 gm gm Industrias Alimentarias" //
					, "2 gm gm Industrias Extractivas" //
					, "2 gm gm Inform�tica y Comunicaciones" //
					, "2 gm gm Instalaci�n y Mantenimiento" //
					, "2 gm gm Madera, Mueble y Corcho" //
					, "2 gm gm Mar�timo-Pesquera" //
					, "2 gm gm Qu�mica" //
					, "2 gm gm Sanidad" //
					, "2 gm gm Seguridad y Medio Ambiente" //
					, "2 gm gm Servicios Socioculturales y a la Comunidad" //
					, "2 gm gm Textil, Confecci�n y Piel" //
					, "2 gm gm Transporte y Mantenimiento de Veh�culos" //
					, "2 gm gm Vidrio y Cer�mica" //

					, "1 gspf Actividades F�sicas y Deportivas" //
					, "1 gspf Administraci�n y Gesti�n" //
					, "1 gspf Agraria" //
					, "1 gspf Artes Gr�ficas" //
					, "1 gspf Artes y Artesan�as" //
					, "1 gspf Comercio y Marketing" //
					, "1 gspf Edificaci�n y Obra Civil" //
					, "1 gspf Electricidad y Electr�nica" //
					, "1 gspf Energ�a y Agua" //
					, "1 gspf Fabricaci�n Mec�nica" //
					, "1 gspf Hosteler�a y Turismo" //
					, "1 gspf Imagen Personal" //
					, "1 gspf Imagen y Sonido" //
					, "1 gspf Industrias Alimentarias" //
					, "1 gspf Industrias Extractivas" //
					, "1 gspf Inform�tica y Comunicaciones" //
					, "1 gspf Instalaci�n y Mantenimiento" //
					, "1 gspf Madera, Mueble y Corcho" //
					, "1 gspf Mar�timo-Pesquera" //
					, "1 gspf Qu�mica" //
					, "1 gspf Sanidad" //
					, "1 gspf Seguridad y Medio Ambiente" //
					, "1 gspf Servicios Socioculturales y a la Comunidad" //
					, "1 gspf Textil, Confecci�n y Piel" //
					, "1 gspf Transporte y Mantenimiento de Veh�culos" //
					, "1 gspf Vidrio y Cer�mica" //
					//
					, "2 gspf Actividades F�sicas y Deportivas" //
					, "2 gspf Administraci�n y Gesti�n" //
					, "2 gspf Agraria" //
					, "2 gspf Artes Gr�ficas" //
					, "2 gspf Artes y Artesan�as" //
					, "2 gspf Comercio y Marketing" //
					, "2 gspf Edificaci�n y Obra Civil" //
					, "2 gspf Electricidad y Electr�nica" //
					, "2 gspf Energ�a y Agua" //
					, "2 gspf Fabricaci�n Mec�nica" //
					, "2 gspf Hosteler�a y Turismo" //
					, "2 gspf Imagen Personal" //
					, "2 gspf Imagen y Sonido" //
					, "2 gspf Industrias Alimentarias" //
					, "2 gspf Industrias Extractivas" //
					, "2 gspf Inform�tica y Comunicaciones" //
					, "2 gspf Instalaci�n y Mantenimiento" //
					, "2 gspf Madera, Mueble y Corcho" //
					, "2 gspf Mar�timo-Pesquera" //
					, "2 gspf Qu�mica" //
					, "2 gspf Sanidad" //
					, "2 gspf Seguridad y Medio Ambiente" //
					, "2 gspf Servicios Socioculturales y a la Comunidad" //
					, "2 gspf Textil, Confecci�n y Piel" //
					, "2 gspf Transporte y Mantenimiento de Veh�culos" //
					, "2 gspf Vidrio y Cer�mica" //

					//
					//
			};
			int opcion = -1;
			do {
				if (opcion == 0) {
					System.err.println("no se puede");

				} else if (opcion > 0) {
					this.curso = menu[opcion];
				}
				opcion = Utilidad.leer().leer_opcion_menu("", menu);
			} while (true);
		}
	}

	@Override
	public String toString() {
		return String.format("%s|", curso);
	}

}