package p;

import Funcion.Leer;

public class Empleado extends Persona {

  public int year;

  public int num_depach;

public Empleado() {
	super();
	do {
		String leerCadena = Leer.leerCadena("a�o");
		try {
			year = Integer.parseInt(leerCadena);
			if (("" + year).matches("\\d{4}")) {
				break;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);	do {
		String leerCadena = Leer.leerCadena("num_depach");
		try {
			num_depach = Integer.parseInt(leerCadena);
			if (("" + num_depach).matches("\\d{4}")) {
				break;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
}
}