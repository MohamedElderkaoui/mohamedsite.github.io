package app;

import java.util.Arrays;

import Funcion.Leer;
import Funcion.Utilidad;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TragaBola[] tragaBolas = new TragaBola[0];
		String[] menu = { "salir",
				"Crear tragaBolas" + "Darle de comer" + "Hacerle trotar" + "Hacerle dormir" + "Ver estado." };
		int opcion = -1;
		do {
			if (opcion == 1) {
				ver(tragaBolas);
				String color = "";
				color = ponecolor();

				int maxBolas = 0;
				do {
					try {
						maxBolas = Integer.parseInt(Leer.leerCadena(""));
						if (maxBolas > 0)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				TragaBola nuevoTragaBola = new TragaBola(color, maxBolas);

				if (Arrays.asList(tragaBolas).contains(nuevoTragaBola)) {
					tragaBolas = Arrays.copyOf(tragaBolas, tragaBolas.length + 1);
					for (int i = 0; i < tragaBolas.length; i++) {
						TragaBola j = tragaBolas[i];
						if (j == null) {
							tragaBolas[i] = nuevoTragaBola;
							break;
						}
					}
				}

				ver(tragaBolas);

			} else if (opcion == 2) {
				ver(tragaBolas);
				int objectopcion = -1;
				do {
					try {
						objectopcion = Integer.parseInt(Leer.leerCadena(""));
						if (objectopcion > -1)
							if (objectopcion<tragaBolas.length)
								break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				tragaBolas[objectopcion].comer();
				ver(tragaBolas);
			} else if (opcion == 3) {
				ver(tragaBolas);	int objectopcion = -1;
				do {
					try {
						objectopcion = Integer.parseInt(Leer.leerCadena(""));
						if (objectopcion > -1)
							if (objectopcion<tragaBolas.length)
								break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				tragaBolas[objectopcion].trotar();
				ver(tragaBolas);
			} else if (opcion == 4) {
				ver(tragaBolas);	int objectopcion = -1;
				do {
					try {
						objectopcion = Integer.parseInt(Leer.leerCadena(""));
						if (objectopcion > -1)
							if (objectopcion<tragaBolas.length)
								break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} while (true);
				tragaBolas[objectopcion].dormir();
				ver(tragaBolas);
			} else if (opcion == 5) {
				ver(tragaBolas);
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
	}

	private static String ponecolor() {
		// TODO Auto-generated method stub
		String[] menu = { "salir", "azul", "amarillo", "rojo", "verde" };
		int opcion = -1;
		do {
			if (opcion == 1) {
				return "azul";

			} else if (opcion == 2) {
				return "amarillo";
			} else if (opcion == 3) {
				return "rojo";
			} else if (opcion == 4) {
				return "verde";
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
		return "";
	}

	public static void ver(TragaBola[] tragaBolas) {
		String t = "\n";
		t += String.format("+%s+%s+%s+\n", Utilidad.c(10, ""), Utilidad.c(10, ""), Utilidad.c(10, "")).replace(" ",
				"-");
		t += String.format("|%s|%s|%s|\n", Utilidad.c(10, "color"), Utilidad.c(10, "comido"), Utilidad.c(10, "maximo"));
		t += String.format("+%s+%s+%s+\n", Utilidad.c(10, ""), Utilidad.c(10, ""), Utilidad.c(10, "")).replace(" ",
				"-");
		for (TragaBola i : tragaBolas) {
			t += i.visualizar();
		}
		System.out.println(t);
	}

}
