package app;

import Funcion.Utilidad;

public class TragaBola {
	private String color;
	private Integer bolasComidas;
	private Integer maxBolas;

	public TragaBola(String color, Integer maxBolas) {
		this.color = color;
		this.maxBolas = maxBolas;
		this.bolasComidas = 0;
	}

	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the bolasComidas
	 */
	public Integer getBolasComidas() {
		return bolasComidas;
	}

	/**
	 * @param bolasComidas the bolasComidas to set
	 */
	public void setBolasComidas(Integer bolasComidas) {
		this.bolasComidas = bolasComidas;
	}

	/**
	 * @return the maxBolas
	 */
	public Integer getMaxBolas() {
		return maxBolas;
	}

	/**
	 * @param maxBolas the maxBolas to set
	 */
	public void setMaxBolas(Integer maxBolas) {
		this.maxBolas = maxBolas;
	}

	@Override
	public String toString() {
		return String.format("|%s|%s|%s|", Utilidad.c(10, color), Utilidad.c(10, bolasComidas),
				Utilidad.c(10, maxBolas));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bolasComidas == null) ? 0 : bolasComidas.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		result = prime * result + ((maxBolas == null) ? 0 : maxBolas.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof TragaBola)) {
			return false;
		}
		TragaBola other = (TragaBola) obj;
		if (bolasComidas == null) {
			if (other.bolasComidas != null) {
				return false;
			}
		} else if (!bolasComidas.equals(other.bolasComidas)) {
			return false;
		}
		if (color == null) {
			if (other.color != null) {
				return false;
			}
		} else if (!color.equals(other.color)) {
			return false;
		}
		if (maxBolas == null) {
			if (other.maxBolas != null) {
				return false;
			}
		} else if (!maxBolas.equals(other.maxBolas)) {
			return false;
		}
		return true;
	}

	public String visualizar() {
		// TODO Auto-generated method stub
		return String.format("|%s|%s|%s|\n", Utilidad.c(10, color), Utilidad.c(10, bolasComidas),
				Utilidad.c(10, maxBolas))+ String.format("+%s+%s+%s+\n", Utilidad.c(10, ""),Utilidad.c(10, ""),Utilidad.c(10, "")).replace(" ", "-");

	}

	public void comer() {
		if ((getBolasComidas() + 1) <= getMaxBolas()) {
			setBolasComidas(getBolasComidas() + 1);
			System.out.println("He comido una bola");
		}
	}

	public void trotar() {
		if ((getBolasComidas() - 1) >= 1) {
			setBolasComidas(getBolasComidas() - 1);
			System.out.println("He trotado");
		}
	}

	public void dormir() {
		if ((getBolasComidas() / 2) >= 1) {
			setBolasComidas(getBolasComidas() / 2);
			System.out.println("ripa llena. ZZZZ");
		}
	}
}
