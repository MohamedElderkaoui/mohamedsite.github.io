package Cadernas;
import Funcion.Utilidad;
public class Ejer01 {
	public static void main(String[] args) {
		String n = "";
		do {
			n=Utilidad.leer().leerCadena("introduci.");
			if (n.length()<90) {
				break;
			}
		} while (true);
		for (int i = 0; i < n.length(); i++) {
			for (int j = 0; j <=i; j++) {
				System.out.print(n.charAt(j));
				
			}System.out.println();
		}
	}
}
