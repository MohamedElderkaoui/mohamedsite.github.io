package Cadernas;

import java.util.Arrays;

import Funcion.Utilidad;
import Funcion.Utilidad;
public class Ejer11 {
	public static void main(String[] args) {
		String _n = Utilidad.leer().leerCadena("INTRODUCI");
		for (int i = 0; i < _n.length(); i++) {
			System.out.println(_n);
			_n=_n.substring(_n.length()-1, _n.length())+_n.substring(0, _n.length()-1);
		}
	}
}
