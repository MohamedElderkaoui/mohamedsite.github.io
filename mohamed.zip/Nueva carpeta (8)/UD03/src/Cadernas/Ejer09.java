package Cadernas;

import Funcion.Utilidad;

public class Ejer09 {
	public static void main(String[] args) {
		String n = "",t="";
		String LETRAMIN = "AEOUIaueio";
		String LETRAMAY = "BCDFGHJKLMN�PQRSTVWXYZ"+"BCDFGHJKLMN�PQRSTVWXYZ".toLowerCase();
		String NUM      = "0123456789";
		
int contM=0,contm=0,contn=0;
		
		do {
			n=Utilidad.leer().leerCadena("introduci.");
			if (n.length()<90) {
				break;
			}
		} while (true);
		int opcion = Utilidad.leer().leerEntero("");
		for (int i = 0; i < n.length(); i++) {
			t+=""+(char)(((int)n.charAt(i))+opcion);
		}
		System.out.println(t);
		
		}
}
