package Cadernas;
import Funcion.Utilidad;
public class Ejer03 {
	public static void main(String[] args) {	String textString="",letra="";
	int cont=0;
	do {cont=0;
		textString=Utilidad.leer().leerCadena("frase que introduciremos aque");
		if (textString.length()==0) {
			break;
		} else {
			do {

				letra=Utilidad.leer().leerCadena("frase que introduciremos aque");
		 if (letra.length()!=0) {
			break;
		}
			} while (true);
			for (int i = 0; i < textString.split(" ").length; i++) {
				if (textString.split(" ")[i].compareTo(letra)==0) {
					cont++;
				}
			}
			System.out.printf("en la frase %80s hay %d veces la letra %s", textString,cont,letra);
		}
	} while (true);}
}
