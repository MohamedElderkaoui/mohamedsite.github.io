package Cadernas;

import java.util.Arrays;

import Funcion.Utilidad;

public class Ejer10 {
	public static void main(String[] args) {	
		String str = "BUENOS D�AS TENGAN TODOS POR LA MA�ANA";
		//String str2 = Leer.leerCadena("Introduce cad: ");
		
		
		int posLetra=0;
		
		//String str2 = "BUENAS NOCHES";
		
		
		char letra[] = new char[str.length()]; //60 max
		int veces[] = new int[str.length()];
		
		
		for (int i = 0; i < str.length(); i++) {
			
			//System.out.println(str.charAt(i));
			//ver si existe la letra
			int pos=-1;
			for (int j = 0; j < letra.length; j++) {
				
				if(letra[j] == str.charAt(i)) {
					pos=j;
					//System.out.println("Pos: "+j);
					veces[j]=veces[j]+1;
				}
			}
			
			//Si no la encuentra
			if(pos == -1) {
				letra[posLetra] = str.charAt(i);
				veces[posLetra] = 1;
				posLetra++;
			}
			
			
			
		}
		
		System.out.println(str);
		System.out.println(Arrays.toString(letra));
		System.out.println(Arrays.toString(veces));
		
		//N�mero de letras DIFERENTES
		
		System.out.println("Hay "+posLetra+" letras diferentes.");
		
		//Frecuencia de repetici�n
		
		for (int i = 0; i < letra.length; i++) {
			//if(letra[i] != '')
			if(veces[i] > 0)
				System.out.printf("Letra: %c --> %2d veces.\n",letra[i],veces[i]);
		}
		}
}
