package Cadernas;
import Funcion.Utilidad;
public class Ejer05 {
	public static void main(String[] args) {

		String n = "";
		String LETRAMIN = "abcdefghijklmn�opqrstuvwxyz�������";
		String LETRAMAY = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ�������";
		String NUM      = "0123456789";
		
		String contM= "",contm= "",contn= "";
		
		do {
			n=Utilidad.leer().leerCadena("introduci.");
			if (n.length()<90) {
				break;
			}
		} while (true);

		System.out.println(n.toLowerCase());
		System.out.println(n.toUpperCase());

	}
}
