package Cadernas;
import Funcion.Utilidad;
public class Ejer04 {
	public static void main(String[] args) {

		String n = "";
		String LETRAMIN = "abcdefghijklmn�opqrstuvwxyz�������";
		String LETRAMAY = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ�������";
		String NUM      = "0123456789";
		
		String contM= "",contm= "",contn= "";
		
		do {
			n=Utilidad.leer().leerCadena("introduci.");
			if (n.length()<90) {
				break;
			}
		} while (true);
		for (int i = 0; i < n.length(); i++) {
			String ln = ""+n.charAt(i);
			System.out.printf("%s<-%d\n", ln, (int)n.charAt(i));
			if (LETRAMIN.indexOf(ln)!=-1) {
				contm+=ln;
			}if (LETRAMAY.indexOf(ln)!=-1) {
				contM+=ln;
			}if (NUM.indexOf(ln)!=-1) {
				contn+=ln;			}
		}
		//Imprimimos el resultado
		System.out.println("\n\nTOTAL = " + n);
		System.out.println("minusculas = " + contm);
		System.out.println("mayusculas = " + contM);
		System.out.println("n�meros = " + contn);
	
	}
}
