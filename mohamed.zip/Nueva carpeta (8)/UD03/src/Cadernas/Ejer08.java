package Cadernas;

import Funcion.Utilidad;

public class Ejer08 {
	public static void main(String[] args) {
		String n = "", t = "";
		int con = 0;
		do {
			n=Utilidad.leer().leerCadena("");
			if (n.compareTo("00000000")!=0) {
				if (n.substring(0, 3).compareTo("199")==0) {
					if ("012345".indexOf(n.substring(3, 4))!=-1) {
						if ("HM".indexOf(n.substring(4,5))!=-1) {
							if ("12".indexOf(n.substring(5,6))!=-1) {
								con++;
							}	
						}
					}
				}
			} else {break;
			}
		} while (true);
		System.out.println("HAY"+con);
	}
}
