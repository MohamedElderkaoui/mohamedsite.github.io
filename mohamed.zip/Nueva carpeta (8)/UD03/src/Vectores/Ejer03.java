package Vectores;

import java.util.Arrays;
import java.util.Random;

import Funcion.Utilidad;

public class Ejer03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] v_int = new int[10];
		Random random = new Random();

		Arrays.setAll(v_int, (i) -> Utilidad.leer().leerEntero("" + i));
		System.out.println(Arrays.toString(v_int));
		int max = v_int[0], min = v_int[0];
		for (int j : v_int) {
			if (j > max) {
				max=j;
			}
			if (j<min) {
				min=j;
			}
		}
		System.out.printf("maximo:%d\nminimo=%d", max,min);System.out.println();
		for (int j = 0; j < v_int.length; j++) {
			if (v_int[j]== max) {
				max=j;	System.out.printf("maximoposio:%d", max);

			}
			if (v_int[j]==min) {
				min=j;
			}
		}System.out.println();
		for (int j = 0; j < v_int.length; j++) {
			if (v_int[j]== max) {
				max=j;	

			}
			if (v_int[j]==min) {
				min=j;System.out.printf("minimoposio:%d", min);
			}
		}
	}

}
