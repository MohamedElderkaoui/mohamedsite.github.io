package Vectores;

import java.util.Arrays;
import java.util.Random;

import Funcion.Utilidad;

public class Ejer01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] v_int = new int[10];
		Random random = new Random();

		Arrays.setAll(v_int, (i) -> (int) Math.ceil(random.nextDouble() * 20) - 10);
		System.out.println(Arrays.toString(v_int));
		double miMedia = Utilidad.leer().miMedia(v_int);
		System.out.println(miMedia);
		System.out.println(Utilidad.c(28, "").replace(" ", "-"));
		System.out.println(miMedia);
		for (int i : v_int) {
			if (miMedia < i)
				System.out.printf("%4d,", i);
		}
		System.out.println();
		for (int i : v_int) {
			if (miMedia == i)
				System.out.printf("%4d,", i);
		}
		System.out.println();
		for (int i : v_int) {
			if (miMedia > i)
				System.out.printf("%4d,", i);
		}
		System.out.println();
System.out.println(Arrays.asList(v_int).contains(2));
	}

}
