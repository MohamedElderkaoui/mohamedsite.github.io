package Vectores;

import java.util.Arrays;
import java.util.Random;

import Funcion.Utilidad;

public class Ejer02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] v_int = new int[10],v_int2= new int[10],v_intdesuma= new int[10];
		Random random = new Random();

		Arrays.setAll(v_int, (i) -> (int) Math.ceil(random.nextDouble() * 20) - 10);
		System.out.println(Arrays.toString(v_int));
		Arrays.setAll(v_int2, (i) -> (int) Math.ceil(random.nextDouble() * 20) - 10);
		System.out.println(Arrays.toString(v_int2));
	
		v_intdesuma=Arrays.copyOf(v_int, v_int.length);
for (int i = 0; i < v_intdesuma.length; i++) {
	v_intdesuma[i]+=v_int2[i];
}
System.out.println(Arrays.toString(v_intdesuma));

	}

}
