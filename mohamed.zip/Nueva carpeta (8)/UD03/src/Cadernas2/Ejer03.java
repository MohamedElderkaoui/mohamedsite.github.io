package Cadernas2;

import Funcion.Utilidad;

public class Ejer03 {
	public static void main(String[] args) {
		String textString = "", textString2 = "";
		int cont = 0;
		textString=Utilidad.leer().leerCadena("intoducer");
		for (int i = textString.length()-1; i >-1; i--) {
			textString2+=textString.charAt(i)+"";
		}
		System.out.println(textString);
		System.out.println(textString2);
		System.out.println(((textString.compareTo(textString2)==0)?"es pal�ndromo ":"no es pal�ndromo "));
	}
}
