package Cadernas2;
import Funcion.Utilidad;
public class Ejer01 {
	public static void main(String[] args) {
		String n = Utilidad.leer().leerCadena(""), t ;
		int con = 0;
		
		do {
			t=Utilidad.leer().leerCadena("introduci.");
			if (t.length()==1) {
				break;
			}
		} while (true);
		System.out.println(n);
		n=n.replace(t	," ");
		System.out.println(n);
			
	}
}
