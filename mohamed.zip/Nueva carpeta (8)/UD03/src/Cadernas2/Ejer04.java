package Cadernas2;
import Funcion.Utilidad;
public class Ejer04 {
	public static void main(String[] args) {
		String _n = "";
		_n=Utilidad.leer().leerCadena("introducer la frase");
		System.out.println(_n.charAt(_n.length()-1)+_n.substring(1, _n.length()-1)+_n.charAt(0));
	}
}
