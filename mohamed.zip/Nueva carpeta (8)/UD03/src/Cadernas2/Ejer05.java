package Cadernas2;

import Funcion.Utilidad;

public class Ejer05 {
	public static void main(String[] args) {
		String _n = "";
		_n += Utilidad.leer().leerCadena("introducer un  nombre")+"\n";
		_n += Utilidad.leer().leerCadena("introducer otro nombre");
		System.out.println(_n);
	}
}
