package Cadernas2;
import Funcion.Utilidad;
public class Ejer07 {
	public static void main(String[] args) {

		String n = "";
		String LETRAMIN = "AEOUIaueio";
		String LETRAMAY = "BCDFGHJKLMN�PQRSTVWXYZ"+"BCDFGHJKLMN�PQRSTVWXYZ".toLowerCase();
		String NUM      = "0123456789";
		
int contM=0,contm=0,contn=0;
		
		do {
			n=Utilidad.leer().leerCadena("introduci.");
			if (n.length()<90) {
				break;
			}
		} while (true);
		for (int i = 0; i < n.length(); i++) {
			String ln = ""+n.charAt(i);
			System.out.printf("%s<-%d\n", ln, (int)n.charAt(i));
			if (LETRAMIN.indexOf(ln)!=-1) {
				contm++;
			}if (LETRAMAY.indexOf(ln)!=-1) {
				contM++;
			}if (NUM.indexOf(ln)!=-1) {
				contn++;
			}
		}
		//Imprimimos el resultado
		System.out.println("\n\nTOTAL = " + n.length());
		System.out.println("vocal = " + contm);
		System.out.println("consona = " + contM);
		System.out.println("n�meros = " + contn);
		System.out.println("otros = " + (n.length()-contn-contm-contM));
		}
}
