package Cadernas2;
import Funcion.Utilidad;
public class Ejer06 {
	public static void main(String[] args) {
		String n = Utilidad.leer().leerCadena(""), t ;
		int con = 0;
		
		do {
			t=Utilidad.leer().leerCadena("introduci.");
			if (t.compareToIgnoreCase("si")==0) {
				break;
			}	if (t.compareToIgnoreCase("no")==0) {
				break;
			}
		} while (true);
		System.out.println(n);
		n=n.replace(t	," ");
		System.out.println(n);
			
	}
}
