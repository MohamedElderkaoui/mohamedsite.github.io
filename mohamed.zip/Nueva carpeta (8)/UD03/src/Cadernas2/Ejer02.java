package Cadernas2;
import Funcion.Utilidad;
public class Ejer02 {
	public static void main(String[] args) {
		String n = Utilidad.leer().leerCadena(""), t ;
		int con = 0;
		
		do {
			t=Utilidad.leer().leerCadena("introduci.");
			if (t.length()==1) {
				break;
			}
		} while (true);
		System.out.println(n);
		for (int i = 0; i < 3; i++) {
			n = n.replaceFirst(t, " ");
		}
		System.out.println(n);
			
	}
}
