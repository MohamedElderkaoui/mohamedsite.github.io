package app;

import Funcion.Leer;

public class Principal {
	public static void main(String[] args) {
		String texto = "", regret = "[0-9XYZxyz]{1}[0-9]{7}[T|R|W|A|G|M|Y|F|P|D|X|B|N|J|Z|S|Q|V|H|L|C|K|E]{1}";
		do {
			texto = Leer.leerCadena(regret).toUpperCase();
			if (texto.matches(regret)) {
				boolean vadi = vadi(texto);
				if (vadi) {
					System.out.println("cncide");
					break;
				}
			} else {
				System.out.println("no cncide");
			}
		} while (true);

	}

	public static boolean vadi(String texto) {
		// TODO Auto-generated method stub
		String _n = "TRWAGMYFPDXBNJZSQVHLCKE";
		String texto2 = texto.substring(0, 8).toUpperCase()//
				.replace("x".toUpperCase(), "" + 0).replace("y".toUpperCase(), "" + 1)
				.replace("x".toUpperCase(), "" + 2);
		int index = Integer.parseInt(texto2) % 23;
		String x = "" + _n.charAt(index);
		texto2 = texto.replace(texto2.substring(0, 8).toUpperCase(), "");
		boolean b = x.compareTo(texto2) == 0;
		
		System.out.println(texto2);
		System.out.println(x);
		System.out.println(b);
		return b;
	}
}
