package Ejer;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import Funcion.Leer;

public class Ej06 {
public static void main(String[] args) {
	Set<String> uTreeSet=new TreeSet<>(); 
	String tama="";
	do {
		try {
			tama=(Leer.leerCadena(""));
if (tama.compareTo("*")==0) {
	break;
}			uTreeSet.add(tama);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
System.out.println("uTreeSet");
	
	System.out.println(Arrays.toString(uTreeSet.toArray())
					.replace(",", "|"));

}
}
