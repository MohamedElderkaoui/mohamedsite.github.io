package Ejer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import Funcion.Leer;
import Funcion.Utilidad;

public class Ej07 {
	public static void main(String[] args) {
		Map<String, Integer> map = new TreeMap<>();
		Map<Integer, List<String>> map2 = new TreeMap<>();
		
		String tama = "";
		do {
			try {
				tama = (Leer.leerCadena("nombe;"));
				if (tama.compareTo("*") == 0) {
					break;
				} else {
					int not = -1;
					do {
						not = Integer.parseInt(Leer.leerCadena("no"));
						if (not > -1) {
							if (not < 11) {
								map.put(tama, not);
								break;
							}
						}
					} while (true);
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
	if (true) {
		String t = "";
		Comparator<String> comparator = (a, b) -> a.compareTo(b);

		t += "\n+";
		t += Utilidad.c(10, "").replace(" ", "-") + "+";
		t += Utilidad.c(10, "").replace(" ", "-") + "+\n|";
		t += Utilidad.c(10, "nombre") + "|";
		t += Utilidad.c(10, "notr");
		t += "|\n+";
		t += Utilidad.c(10, "").replace(" ", "-") + "+";
		t += Utilidad.c(10, "").replace(" ", "-") + "+\n";
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer val = entry.getValue();
			t += "|" + Utilidad.c(10, key.toString()) + "|";
			t += Utilidad.c(10, val.toString());
			t += "|\n+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+\n";

		}
		System.out.println(t);
	}
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer val = entry.getValue();
			List<String>aus=null;
			if (map2.containsKey(val)) {
aus=map2.get(val);
aus.add(key);
map2.put(val, aus);
			} else {aus=new ArrayList<>();
			Comparator<String> comparator = (a, b) -> a.compareTo(b);
				aus.add(key);
				aus.sort(comparator);
				map2.put(val, aus);
			}
		}	
		extracted();
		extracted();
		extracted();
		extracted();
		extracted();
		extracted();
		extracted();
		extracted();
		if (true) {
			String t = "";

			t += "\n+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+\n|";
			t += Utilidad.c(10, "nombre") + "|";
			t += Utilidad.c(10, "notr");
			t += "|\n+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+";
			t += Utilidad.c(10, "").replace(" ", "-") + "+\n";
			for (Map.Entry<String, Integer> entry : map.entrySet()) {
				String key = entry.getKey();
				Integer val = entry.getValue();
				t += "|" + Utilidad.c(10, key.toString()) + "|";
				t += Utilidad.c(10, val.toString());
				t += "|\n+";
				t += Utilidad.c(10, "").replace(" ", "-") + "+";
				t += Utilidad.c(10, "").replace(" ", "-") + "+\n";

			}
			System.out.println(t);
		}
	}

	public static void extracted() {
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
	}
}
