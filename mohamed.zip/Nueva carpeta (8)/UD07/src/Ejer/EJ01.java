package Ejer;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import Funcion.Leer;

public class EJ01 {
public static void main(String[] args) {
	Set<Integer> u=new HashSet<>(); 
	Set<Integer> uLinkedHashSet=new LinkedHashSet<>(); 
	Set<Integer> uTreeSet=new TreeSet<>(); 
	int tama=0,num=0;
	tama=extracted(tama);
	num=extracted(num);
	for (int i = 0; i < tama; i++) {
		int ra=(int) (Math.random()*num);
		u.add(ra);
		uLinkedHashSet.add(ra);
		uTreeSet.add(ra);
	}
	System.out.println("HashSet");
	System.out.println(Arrays.toString(u.toArray())
			.replace(",", "|"));	
	System.out.println("uLinkedHashSet");
			
	System.out.println(Arrays.toString(uLinkedHashSet.toArray())
					.replace(",", "|"));
	System.out.println("uTreeSet");
	
	System.out.println(Arrays.toString(uTreeSet.toArray())
					.replace(",", "|"));
}

public static int extracted(	int tama) {
;
	do {
		try {
			tama=Integer.parseInt(Leer.leerCadena(""));
			if(tama>0)
				break;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
	return tama;
}
}
