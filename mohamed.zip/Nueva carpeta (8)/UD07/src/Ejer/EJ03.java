package Ejer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import Funcion.Leer;

public class EJ03 {
public static void main(String[] args) {
	List<Integer> u=new ArrayList<>(); 
	List<Integer> uLinkedHashSet=new LinkedList<>(); 
	
	int tama=0,num=0;
	tama=extracted(tama);
	num=extracted(num);
	for (int i = 0; i < tama; i++) {
		int ra=(int) (Math.random()*num);
		u.add(ra);
		uLinkedHashSet.add(ra);
	}
	System.out.println("ArrayList");
	System.out.println(Arrays.toString(u.toArray())
			.replace(",", "|"));	
	System.out.println("uLinkedHashSet");
			
	System.out.println(Arrays.toString(uLinkedHashSet.toArray())
					.replace(",", "|"));
	System.out.println("uTreeSet");
	
	
}

public static int extracted(	int tama) {
;
	do {
		try {
			tama=Integer.parseInt(Leer.leerCadena(""));
			if(tama>0)
				break;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
	return tama;
}
}
