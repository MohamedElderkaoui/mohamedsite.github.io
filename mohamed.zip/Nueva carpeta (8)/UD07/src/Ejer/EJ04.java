package Ejer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import Funcion.Leer;

public class EJ04 {
public static void main(String[] args) {
	List<String> u=new ArrayList<>(); 
	List<String> uLinkedHashSet=new LinkedList<>(); 
	int tama=0,num=0;
	tama=EJ01.extracted(tama);
	for (int i = 0; i < tama; i++) {
String ra=Leer.leerCadena("");
		u.add(ra);
		uLinkedHashSet.add(ra);
	}
	System.out.println("HashSet");
	System.out.println(Arrays.toString(u.toArray())
			.replace(",", "|"));	
	System.out.println("uLinkedHashSet");
			
	System.out.println(Arrays.toString(uLinkedHashSet.toArray())
					.replace(",", "|"));
}
}
