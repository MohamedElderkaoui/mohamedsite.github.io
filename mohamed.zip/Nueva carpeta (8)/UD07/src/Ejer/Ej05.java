package Ejer;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import Funcion.Leer;

public class Ej05 {
public static void main(String[] args) {
	Set<Integer> uTreeSet=new TreeSet<>(); 
	int tama=-1;
	do {
		try {
			tama=Integer.parseInt(Leer.leerCadena(""));
if (tama==-9999) {
	break;
}			uTreeSet.add(tama);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
System.out.println("uTreeSet");
	
	System.out.println(Arrays.toString(uTreeSet.toArray())
					.replace(",", "|"));

}
public static int extracted(	int tama) {
;
	do {
		try {
			tama=Integer.parseInt(Leer.leerCadena(""));
			
				break;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
	return tama;
}
}
