
package EJERS;


import Funcion.Utilidad;

public class Ejer08 {
	public static void main(String[] args) {
		int p = 0, q = 0,min=0,max, m = 0, n = 0,m_n=0;
		String t="";
		
		p = leerr(p);
			q = leerr(p);
			max=Math.max(p,q );
			min=Math.max(p,q );
	t+=String.format("m!/(n!*(m-n)!)=", p);
		try {
			m=factorial(max);
			n=factorial(min);
			m_n=factorial(max-min);
		} catch (StackOverflowError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t+=String.format("%d", m/(n*m_n));
		System.out.println(t);
		}

	public static int leerr(int p) {
		do {
			try {
				p = Integer.parseInt(Utilidad.leer().leerCadena("num" + Utilidad.c(10, "")));
				if (p > -1)
					break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return p;
	}

	public static int factorial(int p) {
		// TODO Auto-generated method stub
		if (p<1) {
			return 1;
		} else {	String t="";
				t+=String.format("%d", p);
			//System.out.println(t);
			return p*factorial(p-1);
		}
	}

}
