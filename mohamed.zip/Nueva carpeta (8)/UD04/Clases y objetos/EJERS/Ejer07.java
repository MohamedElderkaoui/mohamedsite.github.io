
package EJERS;

import Funcion.Utilidad;

public class Ejer07 {
	public static void main(String[] args) {
		String[] menu = { "salir", " la longitud del circulo de radio r ", "la superficie del circulo",
				"el volumen de una esfera " };
		int opcion = -1;
		double pi = Math.PI;
		do {
			if (opcion == 1) {
				int r =  leerr();
				System.out.printf(" la longitud del circulo de radio %d dada por la expresi�n 2*pi*r=%6.2 ", r,2*pi*r);
			} else if (opcion == 2) {
				int r = leerr();
				System.out.printf("la superficie del circulo dada por la expresi�n pi*r*r=%6.2 ", r,r*pi*r);
			} else if (opcion == 3) {
				int r = leerr();
				System.out.printf(" la longitud del esfera de radio %d dada por la expresi�n 4/3*pi*r3=%6.2 ", r,4/3*pi*r*r);
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
	}public static int leerr() {int p=0;
		do {
			try {
				p = Integer.parseInt(Utilidad.leer().leerCadena("num" + Utilidad.c(10, "")));
				if (p > 1)
					break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return p;
	}
}
