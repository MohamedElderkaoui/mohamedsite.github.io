package EJERS;

import Funcion.Utilidad;

public class Ejer01 {
	public static void main(String[] args) {
		int leerEntero =
				0;
do {
	leerEntero = Utilidad.leer().leerEntero("");
	if (leerEntero>2) {
		break;
	}
} while (true);		
		String esprimo=isPrimO(leerEntero);
		System.out.println(esprimo);
	}

	public static String isPrimO(int leerEntero) {
		// TODO Auto-generated method stub
		boolean b=false;
		for (int i = 2; i <Math.abs(leerEntero)/2; i++) {
			if ((leerEntero%i)==0) {
				b=!b;break;
				
			}
		}
	if (!b) {
		return "es primo";
	} else {
		return "esno primo";
	}}

}
