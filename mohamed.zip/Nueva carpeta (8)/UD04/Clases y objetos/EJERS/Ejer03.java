
package EJERS;


import Funcion.Utilidad;

public class Ejer03 {
	public static void main(String[] args) {
		int p = 0, q = 0, div_p = 0, div_q = 0;
		String t="";
		p = leerr(p);
		t+=String.format("%d�=", p);
		try {
			p=factorial(p);
		} catch (StackOverflowError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t+=String.format("%d", p);
		System.out.println(t);
		}

	public static int leerr(int p) {
		do {
			try {
				p = Integer.parseInt(Utilidad.leer().leerCadena("num" + Utilidad.c(10, "")));
				if (p > -1)
					break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return p;
	}

	public static int factorial(int p) {
		// TODO Auto-generated method stub
		if (p<1) {
			return 1;
		} else {	String t="";
				t+=String.format("%d", p);
			System.out.println(t);
			return p*factorial(p-1);
		}
	}

}
