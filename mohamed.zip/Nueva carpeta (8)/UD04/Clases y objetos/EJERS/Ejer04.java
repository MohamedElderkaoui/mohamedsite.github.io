
package EJERS;


import Funcion.Utilidad;

public class Ejer04 {
	public static void main(String[] args) {
		int p = 0, q = 0, div_p = 0, div_q = 0;
		p = leerr(p);
		boolean esPrimo = es(p);
		System.out.println(((esPrimo) ? "es primo" : "no es primo"));
	}

	public static boolean es(int p) {
		return Utilidad.leer().esPrimo(p);
	}

	public static int leerr(int p) {
		do {
			try {
				p = Integer.parseInt(Utilidad.leer().leerCadena("num" + Utilidad.c(10, "")));
				if (p > 1)
					break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return p;
	}

	private static int saca_divisiores_de_num(int p) {
		// TODO Auto-generated method stub
		int div = 0;
		String t="[";
		for (int i = 2; i < Math.abs(p) + 1; i++) {
			
			if (p % i == 0) {
				t+=String.format("%5d;", i);
				//System.out.printf("%5d;", 2);
				div++;
			}
		}
		t+="]";
		System.out.println(t);
		return div;
	}

}
