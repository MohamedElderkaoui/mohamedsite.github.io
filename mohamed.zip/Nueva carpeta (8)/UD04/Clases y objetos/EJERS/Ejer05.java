
package EJERS;

import Funcion.Utilidad;

public class Ejer05 {
	public static void main(String[] args) {
		int p = 0, q = 0, max = 0, div_q = 0;
		p = leerr(p);
		max = p;
		q = leerr(q);
		if (max < q) {
			max = p;
		}
		int mdc = mcd(max, p, q);
		System.out.println(String.format("mcd(%d,%d)=%6d", p, q, mdc));
	}

	private static int mcd(int max, int p, int q) {
		// TODO Auto-generated method stub
		int mdc = 0;
		int j =Math.max(p, q);
		for (int i = j-1; i >1	; i--) {
			int aus = i;
			System.out.println(p % i);
			System.err.println(q % i);
			if (p % i == 0) {
				if (q % i == 0) {
					mdc = i;
					break;
				}
			}
		}
		return mdc;
	}

	public static int leerr(int p) {
		do {
			try {
				p = Integer.parseInt(Utilidad.leer().leerCadena("num" + Utilidad.c(10, "")));
				if (p > 1)
					break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return p;
	}

}
