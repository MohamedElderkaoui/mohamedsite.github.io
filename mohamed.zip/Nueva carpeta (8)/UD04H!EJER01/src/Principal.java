import java.util.Arrays;

import Funcion.Utilidad;

public class Principal {
	public static void main(String[] args) {
		Alumnon[] vectooAlumnons = new Alumnon[0];
		String[] menu = { "salir", "insetarAlumnon"
				,""
				,"" };
		int opcion = -1;
		do {
			if (opcion == 1) {
				String nombre = Utilidad.leer().leerCadena("nombre");
				int edad = 0;
				do {
					try {
						edad = Integer.parseInt(Utilidad.leer().leerCadena("nombre"));
						if (edad > -1)
							break;
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} while (true);
				Alumnon nuevoAlumnon = new Alumnon(nombre, edad);
				if (Arrays.asList(vectooAlumnons).contains(nuevoAlumnon) == false) {
					vectooAlumnons = Arrays.copyOf(vectooAlumnons, vectooAlumnons.length +1);
					for (int i = 0; i < vectooAlumnons.length; i++) {
						if (vectooAlumnons[i] == null) {
							vectooAlumnons[i] = nuevoAlumnon;
							break;
						}
					}
				}
			} else if (opcion == 2) {
			} else if (opcion == 3) {
				String t= "";
				t+="+";
				
				for (Alumnon string : vectooAlumnons) {
					
				}
			} else if (opcion == 0) {
				break;
			}
			opcion = Utilidad.leer().leer_opcion_menu("", menu);
		} while (true);
	}

}
