
public class Alumnon {
private String nomre;
private Integer edad;
public Alumnon(String nomre, Integer edad) {
	this.nomre = nomre;
	this.edad = edad;
}
public String getNomre() {
	return nomre;
}
public void setNomre(String nomre) {
	this.nomre = nomre;
}
public Integer getEdad() {
	return edad;
}
public void setEdad(Integer edad) {
	this.edad = edad;
}
@Override
public String toString() {
	return String.format("Alumnon [nomre=%s, edad=%s]", nomre, edad);
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((edad == null) ? 0 : edad.hashCode());
	result = prime * result + ((nomre == null) ? 0 : nomre.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj) {
		return true;
	}
	if (!(obj instanceof Alumnon)) {
		return false;
	}
	Alumnon other = (Alumnon) obj;
	if (edad == null) {
		if (other.edad != null) {
			return false;
		}
	} else if (!edad.equals(other.edad)) {
		return false;
	}
	if (nomre == null) {
		if (other.nomre != null) {
			return false;
		}
	} else if (!nomre.equals(other.nomre)) {
		return false;
	}
	return true;
}

}
