

public class Reloj {

private	int hora=0,minuto=0,segundo=0;
	public static void main(String[] args) {
		
		try {	int hora=0,minuto=0,segundo=0;
			extracted(hora, minuto, segundo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return the hora
	 */
	public int getHora() {
		return hora;
	}

	public Reloj(int hora, int minuto, int segundo) {
		this.hora = hora;
		this.minuto = minuto;
		this.segundo = segundo;
	}

	/**
	 * @param hora the hora to set
	 */
	public void setHora(int hora) {
		this.hora = hora;
	}

	/**
	 * @return the minuto
	 */
	public int getMinuto() {
		return minuto;
	}

	/**
	 * @param minuto the minuto to set
	 */
	public void setMinuto(int minuto) {
		this.minuto = minuto;
	}

	/**
	 * @return the segundo
	 */
	public int getSegundo() {
		return segundo;
	}

	/**
	 * @param segundo the segundo to set
	 */
	public void setSegundo(int segundo) {
		this.segundo = segundo;
	}

	public static void extracted(int hora, int minuto, int segundo) {
		try {
				System.out.printf("\n%02d:%02d:%02d", hora,minuto,segundo);
				
				segundo++;
				if (segundo==60) {
					minuto++;
					segundo=0;
				}
				if (minuto==60) {
					hora++;
				minuto=0;
				}
				if(hora==24)
					hora=0;
				Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
