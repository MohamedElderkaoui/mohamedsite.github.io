package app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import Funcion.Leer;
import Funcion.Utilidad;

public class EJ6 {
	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance(), calendar2 = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("d-MM-yyyy"),sdf2 = new SimpleDateFormat("EEEE");
		String paton = "1-[0-9]{2}-[0-9]{4}";
		ll(calendar, sdf, paton);
		System.out.println(sdf2.format(calendar.getTime()));
		try {
			calendar2.setTime(sdf.parse(sdf.format(calendar.getTime())));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		calendar2.add(Calendar.MONTH, 1);
		int dw = calendar.get(Calendar.DAY_OF_WEEK);
		int fm = calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
		String t = "";
		t += String.format("+%35s+", " ").replace(" ", "-");
		sdf = new SimpleDateFormat("MMMM-yyyy");
		t += "\n";
		t += String.format("|%35s|", Utilidad.c(35, sdf.format(calendar.getTime())));
		t += "\n+";
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+\n|", " ").replace(" ", "-");
		t += "\n+";
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+\n|", " ").replace(" ", "-");
		for (int i = 0; i <dw-2; i++) {
			t += String.format("%5s|", "");
		}
		for (int i = 1; i <=fm; i++) {
			dw++;
			if(dw==7) {dw=1;
				t += "\n+";
				t += String.format("%5s+", " ").replace(" ", "-");
				t += String.format("%5s+", " ").replace(" ", "-");
				t += String.format("%5s+", " ").replace(" ", "-");
				t += String.format("%5s+", " ").replace(" ", "-");
				t += String.format("%5s+", " ").replace(" ", "-");
				t += String.format("%5s+\n|", " ").replace(" ", "-");	
			}
			calendar2.add(Calendar.DAY_OF_MONTH, 1);
			t += String.format("%5s|", Utilidad.c(5, i));
		}
		for (int i = dw; i < 6; i++) {
			t += String.format("%5s|", "");
		}t += "\n+";
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+", " ").replace(" ", "-");
		t += String.format("%5s+\n|", " ").replace(" ", "-");
		System.out.println(t);
	}

	public static void ll(Calendar calendar, SimpleDateFormat sdf, String paton) {
		do {
			String t = Leer.leerCadena(paton);
			if (t.matches(paton)) {
				try {
					calendar.setTime(sdf.parse(t));
					break;
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} while (true);
		System.out.println(sdf.format(calendar.getTime()));
	}
}
