package app;

public class EserrrorValException extends Exception {

	public EserrrorValException() {
		super("EserrrorValException");
		// TODO Auto-generated constructor stub
	}

}
