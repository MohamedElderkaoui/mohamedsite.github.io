package app;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Vector;

import Funcion.Utilidad;

public class Cuenta {

	private String numeroCuenta;

	private static int numSig;

	private String Clienta;

	private double saldo;

	private Calendar ultimoCiere = Calendar.getInstance();

	private double saldoUltimoCa;

	/**
	 * 
	 * @element-type Movimientos
	 */
	public List<Movimientos> myMovimientos = new ArrayList<>();

	public Movimientos retira(double valor) throws EserrrorValException {
		if ((this.getSaldo() + valor) > this.getSaldo()) {
			Movimientos movimientos = new Movimientos(valor, this);
			saldo += 0;
			myMovimientos.add(movimientos);
			return movimientos;
		} else {
			throw new EserrrorValException();
		}
	}

	public Movimientos ingresa(double valor) throws EserrrorValException {
		if ((this.getSaldo() - valor) > 0) {
			Movimientos movimientos = new Movimientos(valor, this);
			saldo += 0;
			myMovimientos.add(movimientos);
			return movimientos;
		} else {
			throw new EserrrorValException();
		}
	}

	public Movimientos liquidar(double valor, List<Movimientos> mov) {
		return null;
	}

	/**
	 * @return the numeroCuenta
	 */
	public synchronized String getNumeroCuenta() {
		return numeroCuenta;
	}

	/**
	 * @param numeroCuenta the numeroCuenta to set
	 */
	public synchronized void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	/**
	 * @return the clienta
	 */
	public synchronized String getClienta() {
		return Clienta;
	}

	/**
	 * @param clienta the clienta to set
	 */
	public synchronized void setClienta(String clienta) {
		Clienta = clienta;
	}

	/**
	 * @return the saldo
	 */
	public synchronized double getSaldo() {
		return saldo;
	}

	/**
	 * @param saldo the saldo to set
	 */
	public synchronized void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * @return the ultimoCiere
	 */
	public synchronized Calendar getUltimoCiere() {
		return ultimoCiere;
	}

	/**
	 * @param ultimoCiere the ultimoCiere to set
	 */
	public synchronized void setUltimoCiere(Calendar ultimoCiere) {
		this.ultimoCiere = ultimoCiere;
	}

	/**
	 * @return the saldoUltimoCa
	 */
	public synchronized double getSaldoUltimoCa() {
		return saldoUltimoCa;
	}

	/**
	 * @param saldoUltimoCa the saldoUltimoCa to set
	 */
	public synchronized void setSaldoUltimoCa(double saldoUltimoCa) {
		this.saldoUltimoCa = saldoUltimoCa;
	}

	/**
	 * @return the myMovimientos
	 */
	public synchronized List<Movimientos> getMyMovimientos() {
		return myMovimientos;
	}

	/**
	 * @param myMovimientos the myMovimientos to set
	 */
	public synchronized void setMyMovimientos(List<Movimientos> myMovimientos) {
		this.myMovimientos = myMovimientos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Clienta == null) ? 0 : Clienta.hashCode());
		result = prime * result + ((myMovimientos == null) ? 0 : myMovimientos.hashCode());
		result = prime * result + ((numeroCuenta == null) ? 0 : numeroCuenta.hashCode());
		long temp;
		temp = Double.doubleToLongBits(saldo);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(saldoUltimoCa);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((ultimoCiere == null) ? 0 : ultimoCiere.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Cuenta)) {
			return false;
		}
		Cuenta other = (Cuenta) obj;
		if (Clienta == null) {
			if (other.Clienta != null) {
				return false;
			}
		} else if (!Clienta.equals(other.Clienta)) {
			return false;
		}
		if (myMovimientos == null) {
			if (other.myMovimientos != null) {
				return false;
			}
		} else if (!myMovimientos.equals(other.myMovimientos)) {
			return false;
		}
		if (numeroCuenta == null) {
			if (other.numeroCuenta != null) {
				return false;
			}
		} else if (!numeroCuenta.equals(other.numeroCuenta)) {
			return false;
		}
		if (Double.doubleToLongBits(saldo) != Double.doubleToLongBits(other.saldo)) {
			return false;
		}
		if (Double.doubleToLongBits(saldoUltimoCa) != Double.doubleToLongBits(other.saldoUltimoCa)) {
			return false;
		}
		if (ultimoCiere == null) {
			if (other.ultimoCiere != null) {
				return false;
			}
		} else if (!ultimoCiere.equals(other.ultimoCiere)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		int width = 40;
		String t = "";
		t += String.format("%s+%s+%s+%s+%s+", Utilidad.c(width, ""), Utilidad.c(width, ""), Utilidad.c(width, ""),
				Utilidad.c(width, ""), Utilidad.c(width, "")).replace(" ", "-");
		t += String.format("%s|%s|%s|%s|%s|", Utilidad.c(width, "nu"), Utilidad.c(width, "fcha"), Utilidad.c(width, "in"),
				Utilidad.c(width, "retiradA"), Utilidad.c(width, "A"));
		t += String.format("%s+%s+%s+%s+%s+", Utilidad.c(width, ""), Utilidad.c(width, ""), Utilidad.c(width, ""),
				Utilidad.c(width, ""), Utilidad.c(width, "")).replace(" ", "-");
		for (Movimientos I : myMovimientos) {
			t+=I.toString();
		}
		return String.format("%s| %s| \n%s\n; %s|\n", numeroCuenta, Clienta, t, saldo);
	}

	public Cuenta(String clienta, double saldo) {
		Clienta = clienta;
		this.saldo = saldo;
		numeroCuenta = String.format("cc$04d", numSig);
		numSig++;

	}

}