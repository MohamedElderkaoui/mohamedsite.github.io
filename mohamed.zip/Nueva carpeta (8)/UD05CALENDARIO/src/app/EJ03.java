package app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import Funcion.Leer;

public class EJ03 {
	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance(), calendar2 = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyyhh:mm:ss");
		String paton = "[0-9]{2}-[0-9]{2}-[0-9]{4}[0-9]{2}:[0-9]{2}:[0-9]{2}";
		ll(calendar, sdf, paton);
		try {
			calendar2.setTime(sdf.parse(sdf.format(calendar.getTime())));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int d=Leer.leerEntero("dia"),h=Leer.leerEntero("h"),m=Leer.leerEntero("m"),s=Leer.leerEntero("s");
		calendar2.add(Calendar.DAY_OF_MONTH, d);
		calendar2.add(Calendar.HOUR, h);
		calendar2.add(Calendar.MINUTE, m);
		calendar2.add(Calendar.SECOND, s);
		System.out.printf("diferenncia de dia en %s +%d dia %dh %dm %d= %s es %d %d %d %d", //
				sdf.format(calendar.getTime()),sdf.format(calendar2.getTime()),
				/**/((calendar.getTimeInMillis()-calendar2.getTimeInMillis())/(1000*3600*24)),
				/**/(((calendar.getTimeInMillis()-calendar2.getTimeInMillis())%(1000*3600*24))/(1000*3600)),
				/**/(((calendar.getTimeInMillis()-calendar2.getTimeInMillis())%(1000*3600))/(1000*60)),
				/**/(((calendar.getTimeInMillis()-calendar2.getTimeInMillis())%(1000*60))/(1000)));
		

	}

	public static void ll(Calendar calendar, SimpleDateFormat sdf, String paton) {
		do {
			String t = Leer.leerCadena(paton);
			if (t.matches(paton)) {
				try {
					calendar.setTime(sdf.parse(t));
					break;
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} while (true);
		System.out.println(sdf.format(calendar.getTime()));
	}
}
