package app;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import Funcion.Utilidad;

public class Movimientos {

	private double importe;

	private boolean ingreso_retiro;

	private Calendar fecha = Calendar.getInstance();

	private Cuenta cuenter;

	public Movimientos(double importe, Cuenta cuenter) {
		this.importe = importe;
		this.ingreso_retiro = importe >= 0;
		this.fecha = Calendar.getInstance();
		this.cuenter = cuenter;
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyyhh:mm:ss");
		int width = 40;
		String t = ingreso_retiro
				? String.format("%s|%s|%s|%s|%s|\n", Utilidad.c(width, cuenter.getNumeroCuenta()),
						Utilidad.c(width, sdf.format(fecha.getTime())),
						Utilidad.c(width, String.format("�%,10.2F", importe)), Utilidad.c(width, ""),
						Utilidad.c(width, String.format("�%,10.2F", cuenter.getSaldo())).replace(" ", "-"))
				: String.format("%s|%s|%s|%s|%s|", Utilidad.c(width, cuenter.getNumeroCuenta()),
						Utilidad.c(width, sdf.format(fecha.getTime())), Utilidad.c(width, ""),
						Utilidad.c(width, String.format("�%,10.2F", importe)),
						Utilidad.c(width, String.format("�%,10.2F", cuenter.getSaldo())).replace(" ", "-"));
		t += String.format("%s+%s+%s+%s+%s+", Utilidad.c(width, ""), Utilidad.c(width, ""), Utilidad.c(width, ""),
				Utilidad.c(width, ""), Utilidad.c(width, "")).replace(" ", "-");
		return t;
	}

	/**
	 * @return the importe
	 */
	public synchronized double getImporte() {
		return importe;
	}

	/**
	 * @param importe the importe to set
	 */
	public synchronized void setImporte(double importe) {
		this.importe = importe;
	}

	/**
	 * @return the ingreso_retiro
	 */
	public synchronized boolean isIngreso_retiro() {
		return ingreso_retiro;
	}

	/**
	 * @return the cuenter
	 */
	public synchronized Cuenta getCuenter() {
		return cuenter;
	}

	/**
	 * @param cuenter the cuenter to set
	 */
	public synchronized void setCuenter(Cuenta cuenter) {
		this.cuenter = cuenter;
	}

}