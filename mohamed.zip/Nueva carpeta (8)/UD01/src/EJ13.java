
public class EJ13 {
public static void main(String[] args) {
	int num = EJ07.leer(""),numt=0;
	for (int i = num; i > -1; i--) {
		numt+=i;
	}
	System.out.println(String.format("la suma de los %d primeros n�meros naturales es %d "
			, num,numt));
}
}
