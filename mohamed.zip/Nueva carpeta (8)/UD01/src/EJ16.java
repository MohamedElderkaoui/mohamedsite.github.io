import java.util.Scanner;

public class EJ16 {
public static void main(String[] args) {
	int cont=3;
	String textString="";
	do {
		Scanner teclado = new Scanner(System.in);
	System.out.print(cont+";");
		textString=teclado.nextLine();
	if (textString.compareTo("eureka")==0) {
		System.out.println("esta dentro");break;
	}
	
		cont--;
		if (cont==0) {
			System.out.println("esta dado un error de login");break;
		}
	} while (true);
}
}
