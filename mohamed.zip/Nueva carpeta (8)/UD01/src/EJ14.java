
public class EJ14 {
public static void main(String[] args) {
	int num = EJ07.leer(""),numt=0;
	numt=num;
	if (num%2!=0) {
		numt+=1;
	}
	for (int i = num; i > -1; i--) {
		System.out.print(String.format("%10d| ", numt));
		numt+=2;
	}
	System.out.println(String.format("la suma de los %d primeros n�meros naturales es %d "
			, num,numt));
}
}
