
public class EJ17 {
	public static void main(String[] args) {
		int max = 0, cont = 0, sum = 0, min = 0, num = EJ07.leer("");
		max = num;
		min = num;
		do {
			if (num == 0) {
				break;
			}
			max = num;
			min = num;
			sum += num;
			cont++;
			num = EJ07.leer("");
		} while (true);
		if (cont!=0) {

			System.out.println(String.format("maximo es %d	", max));
			System.out.println(String.format("minimo es %d	", min));
			int med = extracted(cont, sum);
			System.out.println(String.format("minimo es %d	", med));
		}
	}

	public static int extracted(int cont, int sum) {
		return sum/cont;
	}
}
