
public class EJ12 {
public static void main(String[] args) {
	int num = 10;
	for (int i = 0; i < num; i++) {
		System.out.println(String.format("%d->%d", i,i*i));
	}
}
}
