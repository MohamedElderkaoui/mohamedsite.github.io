
public class EJ15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=0,cont=0,sum=0;
		do {
			
			num=EJ07.leer(""+cont);
			if (num==-1) {
				break;
			}cont++;
			sum+=num;
			
		} while (true);
		System.out.println(c(10,"").replace(" ", "_"));
		System.out.println(c(10,"").replace(" ", "_"));
		System.out.println(sum/cont);
	}
	public static String c(int width, String s) {
		return String.format("%-" + width + "s", String.format("%" + (s.length() + (width - s.length()) / 2) + "s", s));
	}

}
