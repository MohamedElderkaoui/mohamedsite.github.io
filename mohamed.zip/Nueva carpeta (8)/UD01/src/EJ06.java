import java.util.Scanner;


/**
 * 
 */

/**
 * @author MOHAMED
 *
 */
public class EJ06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =0/*,b, c,max, min*/;
		a = leer(a);
		if (a>=0) {
			System.out.println(String.format("a=%d", a));
			System.out.println(String.format("a^2=%d", a*2));
			System.out.println(String.format("a^(1/2)=%f",Math.sqrt(a)));
		}
	}

	public static int leer(int a) {
		Scanner teclado = new Scanner(System.in);
		do {
			try {
				System.out.printf("introducer numero a", " ");
				a = Integer.parseInt(teclado.nextLine());
/*				max = a;
				min = a;
			*/	
				break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		return a;
	}

}
