
public class EJ19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int dia = 0, mes = 0, a = 0;
		do {
			dia=EJ07.leer("");
			mes=EJ07.leer("");
			a=EJ07.leer("");
			if (dia > 0) {
				if (mes > 0) {
					if (mes < 13) {
						if (mes == 1) {
							if (dia < 32) {
								System.out.println(String.format("%2d de enero de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}
						} else if (mes == 2) {
							if (a % 4 == 0) {
								if (dia < 30) {
									System.out.println(String.format("%2d de febrero de %5d" , dia,a));
									break;
								}else {
									System.err.println("error de frecha");
								}
							} else {
								if (dia < 29) {
									System.out.println(String.format("%2d de febrero de %5d" , dia,a));
									break;
								}else {
									System.err.println("error de frecha");
								}
							}
						} else if (mes == 3) {
							if (dia < 32) {
								System.out.println(String.format("%2d de marzo de %5d" , dia,a));
								break;
							}
						} else if (mes == 4) {
							if (dia < 31) {
								System.out.println(String.format("%2d de abril de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}
						} else if (mes == 5) {
							if (dia < 32) {
								System.out.println(String.format("%2d de mayo de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}

						} else if (mes == 6) {
							if (dia < 31) {
								System.out.println(String.format("%2d de julio de %5d" , dia,a));
								break;
							}
						} else if (mes == 7) {
							if (dia < 32) {
								System.out.println(String.format("%2d de junio de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}

						} else if (mes == 8) {
							if (dia < 32) {
								System.out.println(String.format("%2d de agosto de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}
						} else if (mes == 9) {
							if (dia < 31) {
								System.out.println(String.format("%2d de septiembre de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}

						} else if (mes == 10) {
							if (dia < 32) {
								System.out.println(String.format("%2d de octubre de %5d" , dia,a));
								break;
							}
						} else if (mes == 11) {
							if (dia < 31) {
								System.out.println(String.format("%2d de noviembre de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}

						} else if (mes == 12) {
							if (dia < 32) {
								System.out.println(String.format("%2d de diciembre de %5d" , dia,a));
								break;
							}else {
								System.err.println("error de frecha");
							}
						}

					}
				}
			}
		} while (true);
	}

}
