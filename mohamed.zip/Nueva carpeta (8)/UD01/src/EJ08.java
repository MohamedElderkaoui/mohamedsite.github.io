
public class EJ08 {
public static void main(String[] args) {
	int mes=0,salario=0;
do {
	mes=EJ07.leer("");
	if (mes>0) {
		if (mes<13) {
			break;
		}
	}
} while (true);
salario=EJ07.leer("");
if (mes==10) {
	salario = (int) (salario*1.15);
	System.out.println(String.format("mes %d salario=%d", mes,salario));
	
}else {
	System.out.println(String.format("mes %d salario=%d", mes,salario));
	
}
}
}
