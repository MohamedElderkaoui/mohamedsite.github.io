
public class EJ11 {
public static void main(String[] args) {
	int bachillerato=0;
	bachillerato = extracted("bachillerato",bachillerato);
	if (bachillerato>4) {
		System.out.println("puede hace GSFPDAW");
	}else {
		int puebaAcceso=0;
		puebaAcceso = extracted(puebaAcceso);
		if (puebaAcceso>4) {
			System.out.println("puede hace GSFPDAW");
		}else {
			System.out.println("puede hace GSFPDAW");
		}
	}
}

public static int extracted(String text,int bachillerato) {
	bachillerato=0;
	do {
		bachillerato=EJ07.leer(text);
		if (bachillerato<10) {
			if (bachillerato>0) {
				break;
			}
		}
	} while (true);
	return bachillerato;
}
}
