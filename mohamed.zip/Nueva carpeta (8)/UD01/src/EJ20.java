import Funcion.Utilidad;

public class EJ20 {
	public static void main(String[] args) {
		String alumno = "";
		do {
			alumno = Utilidad.leer().leerCadena("");
			if (alumno.isEmpty()) {
				break;
			} else {
				int praactica = 0, teoria = 0, problemas = 0;
				praactica = Utilidad.leer().leerEntero("praactica");
				if (praactica < 0) {
					System.err.println("error en nota");
				} else {
					if (praactica > 10) {
						System.err.println("error en nota");
					} else {
						teoria = Utilidad.leer().leerEntero("teoria");
						if (teoria < 0) {
							System.err.println("error en nota");
						} else {
							if (teoria > 10) {
								System.err.println("error en nota");
							} else {
								problemas = Utilidad.leer().leerEntero("problemas");
								if (problemas < 0) {
									System.err.println("error en nota");
								} else {
									if (problemas> 10) {
										System.err.println("error en nota");
									} else {
										double d = 0.4*problemas;
										System.out.println(String.format(//
												"alumno %spraactica%s teoria %sproblemas %s %s"//
												, Utilidad.c(20, alumno)//
												, Utilidad.c(20, praactica)//
												, Utilidad.c(20, teoria)//
												, Utilidad.c(20, problemas)//
												, Utilidad.c(20, String.format("%f", d))));
										
									}
								}
							}
						}
					}
				}
			}
		} while (true);
	}
}
