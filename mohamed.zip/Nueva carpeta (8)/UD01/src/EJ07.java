import java.util.Scanner;

public class EJ07 {
public static void main(String[] args) {
	int ninio=0,ninia=0,total=0;
	ninio=leer(String.format("%-10s", "ninio"));
	ninia=leer(String.format("%-10s", "ninia"));
	total+=ninio;
	total+=ninia;
	extracted(ninio, total);
	extracted(ninia, total);
}
public static void extracted(int ninio, int total) {
	System.out.print(String.format("%-10s%d", "ninio=",ninio));System.out.println();
	int j = 100*ninio;
	int i = j/total;
	System.out.print(String.format("%-10s%d", "%ninio=",i));System.out.println();
}
public static int leer(String aString) {
	Scanner teclado = new Scanner(System.in);
int a=0;	do {
		try {
			System.out.printf(aString, " ");
			a = Integer.parseInt(teclado.nextLine());
/*				max = a;
			min = a;
		*/	
			break;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} while (true);
	return a;
}
}
