import java.util.Scanner;

public class EJ05 {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a, b, c,max, min;
		Scanner teclado = new Scanner(System.in);
		do {
			try {
				System.out.printf("introducer numero a", " ");
				a = Integer.parseInt(teclado.nextLine());
				max = a;
				min = a;
				break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		do {
			try {
				System.out.printf("introducer numero b", " ");
				b = Integer.parseInt(teclado.nextLine());
				if (max < b) {
					max = b;
				}
				if (min > b) {
					min = b;
				}
				break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		do {
			try {
				System.out.printf("introducer numero c", " ");
				c = Integer.parseInt(teclado.nextLine());
				if (max < c) {
					max = c;
				}
				if (min > c) {
					min = c;
				}
				break;
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		} while (true);

		System.out.printf("A=%s,B=%s,c=%s\n", c(10, "" + a), c(10, "" + b), c(10, "" + c));
if (a>0) {
	System.out.printf("multipica;%10d",(a*b*c));;
}else {
	System.out.printf("suma;%10d",(a+b+c));;
}
	}

	public static String c(int width, String s) {
		return String.format("%-" + width + "s", String.format("%" + (s.length() + (width - s.length()) / 2) + "s", s));
	}

}
