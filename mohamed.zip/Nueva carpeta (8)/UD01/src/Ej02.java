import java.util.Scanner;

public class Ej02 {
	public static void main(String[] args) {
		int a, b, c = 0;
		Scanner teclado = new Scanner(System.in);
		do {
			try {
				System.out.printf("introducer numero a", " ");
				a = Integer.parseInt(teclado.nextLine());
				break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);
		do {
			try {
				System.out.printf("introducer numero b", " ");
				b = Integer.parseInt(teclado.nextLine());
				break;
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (true);

		System.out.printf("A=%s,B=%s\n" + "suma=%s\n" + "ressta=%s\n" + "mutilplicacion=%s\n" + "divisio=%s\n",
				c(10, "" + a) //
				, c(10, "" + b) //
				, c(10, "" + (a + b)) //
				, c(10, "" + (a - b)) //
				, c(10, "" + (a * b)) //
				, c(10, "" + ((b!=0?a/b:""))) //

		);

	}

	public static String c(int width, String s) {
		return String.format("%-" + width + "s", String.format("%" + (s.length() + (width - s.length()) / 2) + "s", s));
	}

}
